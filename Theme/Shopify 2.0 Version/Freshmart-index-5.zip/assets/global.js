$.cookie = function(key, value, options) {
    if (arguments.length > 1 && (!/Object/.test(Object.prototype.toString.call(value)) || value === null || value === undefined)) {
        options = $.extend({}, options);
        if (value === null || value === undefined) {
            options.expires = -1
        }
        if (typeof options.expires === 'number') {
            var days = options.expires,
                t = options.expires = new Date();
            t.setDate(t.getDate() + days)
        }
        value = String(value);
        return (document.cookie = [encodeURIComponent(key), '=', options.raw ? value : encodeURIComponent(value), options.expires ? '; expires=' + options.expires.toUTCString() : '', options.path ? '; path=' + options.path : '', options.domain ? '; domain=' + options.domain : '', options.secure ? '; secure' : ''].join(''))
    }
    options = value || {};
    var decode = options.raw ? function(s) {
        return s
    } : decodeURIComponent;
    var pairs = document.cookie.split('; ');
    for (var i = 0, pair; pair = pairs[i] && pairs[i].split('='); i++) {
        if (decode(pair[0]) === key) return decode(pair[1] || '')
    }
    return null
}

if ((typeof Shopify) === 'undefined') {
    Shopify = {};
}
if (!Shopify.formatMoney) {
    Shopify.formatMoney = function(cents, format) {
        var value = '',
            placeholderRegex = /\{\{\s*(\w+)\s*\}\}/,
            formatString = (format || this.money_format);
        if (typeof cents == 'string') {
            cents = cents.replace('.', '');
        }

        function defaultOption(opt, def) {
            return (typeof opt == 'undefined' ? def : opt);
        }

        function formatWithDelimiters(number, precision, thousands, decimal) {
            precision = defaultOption(precision, 2);
            thousands = defaultOption(thousands, ',');
            decimal = defaultOption(decimal, '.');
            if (isNaN(number) || number == null) {
                return 0;
            }
            number = (number / 100.0).toFixed(precision);
            var parts = number.split('.'),
                dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands),
                cents = parts[1] ? (decimal + parts[1]) : '';
            return dollars + cents;
        }
        switch (formatString.match(placeholderRegex)[1]) {
            case 'amount':
                value = formatWithDelimiters(cents, 2);
                break;
            case 'amount_no_decimals':
                value = formatWithDelimiters(cents, 0);
                break;
            case 'amount_with_comma_separator':
                value = formatWithDelimiters(cents, 2, '.', ',');
                break;
            case 'amount_no_decimals_with_comma_separator':
                value = formatWithDelimiters(cents, 0, '.', ',');
                break;
        }
        return formatString.replace(placeholderRegex, value);
    };
}

window.novtheme = window.novtheme || {};
var isLoggedIn;
isLoggedIn = false;
var current_width = $(window).width(),
    min_width = 768,
    responsive_mobile = current_width < min_width,
    flag_sticky = false;

var wishListsArr = localStorage.getItem('wishListsArr') ? JSON.parse(localStorage.getItem('wishListsArr')) : [];
localStorage.setItem('wishListsArr', JSON.stringify(wishListsArr));
if (wishListsArr.length) {
    wishListsArr = JSON.parse(localStorage.getItem('wishListsArr'));
};
novtheme.init = function() {
    novtheme.cacheSelectors();
    novtheme.eventBlockCart();
    novtheme.eventAccountCanvas();
    novtheme.popupCart();
    novtheme.NoneThumbnailProductDetail();
    novtheme.VerticalThumbnailProductDetail();
    novtheme.ThumbnailProductDetail();
    novtheme.RelatedBlog();
    novtheme.RelatedProduct();
    novtheme.load_canvas_menu();
    novtheme.NovTogglePage();
    novtheme.Countdown();
    novtheme.click_button_canvas_menu();
    novtheme.productImageSwitch();
    novtheme.goToTop();
    novtheme.goToTopMobile();
    novtheme.NovHeightBoxContent();
    novtheme.MenuSidebar();
    novtheme.NovToggleSearch();
    novtheme.NovEventClickSearchMobile();
    novtheme.HideShowPassword();
    novtheme.NovSearchToggle();
    novtheme.tooltip();
    novtheme.initNovWishListIcons();
    novtheme.doAddOrRemoveWishlistProduct();
    novtheme.doAddOrRemoveWishlist();
    novtheme.variantName();
    novtheme.Nov_iframe_video();
    novtheme.MegaMenuSlider();
    novtheme.SlideshowDealsSlick();
    novtheme.Vertical();
    novtheme.Mainmenu();
    novtheme.LoadmoreByButton();
    novtheme.CollectiontabLoadmore();
    novtheme.BlockCanvasRight();
    novtheme.CollectionPage();
    novtheme.CanvasIndexLeft();
    novtheme.tooltip();
    if (current_width >= 992) {
        novtheme.StickyHeader(true);
        flag_sticky = true;
    }
    if ($('.template-cart').length > 0 ) {
        novtheme.NovStickIn();
    }
};

//Tooltip, activated by hover event
novtheme.tooltip = function() {
    $("body").tooltip({   
        selector: "[data-toggle='tooltip']",
        container: "body"
    });
};
novtheme.swapChildren = function(obj1, obj2) {
    var temp = obj2.children().detach();
    obj2.empty().append(obj1.children().detach());
    obj1.append(temp);
};
novtheme.toggleMobileStyles = function() {
    if (responsive_mobile) {
        $("*[id^='_desktop_']").each(function(idx, el) {
            var target = $('#' + el.id.replace('_desktop_', '_mobile_'));
            if (target) {
                novtheme.swapChildren($(el), target);
            }
        });
    } else {
        $("*[id^='_mobile_']").each(function(idx, el) {
            var target = $('#' + el.id.replace('_mobile_', '_desktop_'));
            if (target) {
                novtheme.swapChildren($(el), target);
            }
        });
    }
};

novtheme.toggleSticky = function(action) {
    if (action == true) {
        $("*[class^='contentsticky_']").each(function(idx, el) {
            var target = $('.' + el.classList['0'].replace('contentsticky_', 'contentstickynew_'));
            if (target.length) {
                novtheme.swapChildren($(el), target);
            }
        });
    } else {
        $("*[class^='contentstickynew_']").each(function(idx, el) {
            var target = $('.' + el.classList['0'].replace('contentstickynew_', 'contentsticky_'));
            if (target.length) {
                novtheme.swapChildren($(el), target);
            }
        });
    }
}

novtheme.StickyHeader = function(flag_sticky) {
    if ($('.site-header').hasClass('sticky-menu')) {
        if (flag_sticky == true) {
            var time;
            var height = $('.site-header').height();
            var flag = true;
            $(window).scroll(function() {
                if (time) clearTimeout(time);
                time = setTimeout(function() {
                    if ($(window).scrollTop() > height) {
                        if (flag == true) {
                            $('#header-sticky').addClass('sticky-menu-active');
                            $('.site-header').css('height', height);
                            novtheme.toggleSticky(true);
                            flag = false;
                        }
                    } else {
                        if (flag == false) {
                            $('#header-sticky').removeClass('sticky-menu-active');
                            novtheme.toggleSticky(false);
                            $('.site-header').css('height', 'auto');
                            flag = true;
                        }
                    }
                }, 100);
            });
        }
    }
}
var flag_sticky = false;
$(window).on('resize', function() {
    var _cw = current_width;
    var _mw = min_width;
    var _w = $(window).width();
    var _toggle = (_cw >= _mw && _w < _mw) || (_cw < _mw && _w >= _mw);
    responsive_mobile = _cw >= _mw;
    current_width = _w;
    if (_toggle) {
        novtheme.toggleMobileStyles();
        novtheme.load_canvas_menu();
        novtheme.NovTogglePage();
        novtheme.NovHeightBoxContent();
        novtheme.popupCart();
    }
    if (current_width <= 768) {
        if (flag_sticky == true) {
            novtheme.toggleSticky(false);
            $('#header-sticky').removeClass('sticky-menu-active');
        }
    } else {}
});

novtheme.initNovWishListIcons = function() {
    if (!wishListsArr.length) {
        return;
    }

    for (var i = 0; i < wishListsArr.length; i++) {
        var icon = $('[data-product-handle="'+ wishListsArr[i] +'"]');
        icon.addClass('whislist-added');
        icon.find('.wishlist-text').text('Remove Wishlist');
    };

    if (typeof(Storage) !== 'undefined') {
        if (wishListsArr.length <= 0) {
            return;
        }

        setTimeout(function() {
            wishListsArr.forEach(function(item) {
                novtheme.setNovAddedForWishlistIcon(item);
            });
        }, 1000);
    } else {
        alert('Storage no support!');
    }
};
novtheme.setNovAddedForWishlistIcon = function(ProductHandle) {
    var wishlistElm = $('[data-product-handle="'+ ProductHandle +'"]');
    var textadd = 'Add To Wishlist';
    var textremove = 'Remove Wishlist';
    idxArr = wishListsArr.indexOf(ProductHandle);

    if (idxArr >= 0) {
        wishlistElm.addClass('whislist-added');
        wishlistElm.find('.wishlist-text').text(textremove);
        wishlistElm.attr('title',textremove);
    }
    else {
        wishlistElm.removeClass('whislist-added');
        wishlistElm.find('.wishlist-text').text(textadd);
        wishlistElm.attr('title',textadd);
    };
};
novtheme.doAddOrRemoveWishlist = function() {
    var iconWishLists = '.item-product [data-icon-wishlist]';
    var textadd = 'Add To Wishlist';
    var textremove = 'Remove Wishlist';
        
    $(document).off('click.addOrRemoveWishlist', iconWishLists).on('click.addOrRemoveWishlist', iconWishLists, function(e) {
        e.preventDefault();

        var self = $(this),
        productId = self.data('id'),
        ProductHandle = self.data('product-handle'),
        idxArr = wishListsArr.indexOf(ProductHandle);

        if (!self.hasClass('whislist-added')) {
            self.addClass('whislist-added');
            self.find('.wishlist-text').text(textremove);
            self.attr({'title':textremove, 'data-original-title':textremove});
            $('.tooltip-inner').text(textremove);

            var title = self.parents('.item-product').find('.product__title').html();
            var image = self.parents('.item-product').find('.product__thumbnail').attr('srcset');

            $('.loading-modal').find('.product-title').html(title);
            $('.loading-modal').find('.product-image').attr('srcset', image);
            $('.loading-modal').find('.btn-wishlist').show();
            $('.loading-modal').css({"opacity": "1", "visibility": "initial", "transform": "translateX(0)", "transition": "all 0.3s"});
            $('.loading-modal').addClass('novload');
            setTimeout(function() {
                $('.loading-modal').css({"opacity": "0", "visibility": "hidden", "transform": "translateX(410px)", "transition": "all 0.3s"});
                $('.loading-modal').removeClass('novload');
            }, 5000);

            if ($('[data-wishlist-container]').length) {
                novtheme.createNovWishListTplItem(ProductHandle);
            };

            wishListsArr.push(ProductHandle);
            localStorage.setItem('wishListsArr', JSON.stringify(wishListsArr));

        } else {
            self.removeClass('whislist-added');
            self.find('.wishlist-text').text(textadd);
            self.attr({'title':textadd, 'data-original-title':textadd});
            $('.tooltip-inner').text(textadd);
            if ($('[data-wishlist-added="wishlist-'+productId+'"]').length) {
                $('[data-wishlist-added="wishlist-'+productId+'"]').remove();
            }

            wishListsArr.splice(idxArr, 1);
            localStorage.setItem('wishListsArr', JSON.stringify(wishListsArr));
        };

        novtheme.setNovAddedForWishlistIcon(ProductHandle);
    });
};
novtheme.doAddOrRemoveWishlistProduct = function() {
    var iconWishLists = '.product-single a[data-icon-wishlist]';

    $(document).off('click.addOrRemoveWishlist', iconWishLists).on('click.addOrRemoveWishlist', iconWishLists, function(e) {
        e.preventDefault();

        var self = $(this),
        productId = self.data('id'),
        ProductHandle = self.data('product-handle'),
        idxArr = wishListsArr.indexOf(ProductHandle);

        if (!self.hasClass('whislist-added')) {
            self.addClass('whislist-added');
            self.find('.wishlist-text').text('Remove Wishlist');

            var title = self.parents('.product-single').find('.product-single__title').html();
            var image = self.parents('.product-single').find('.product-single__photos .thumblist .thumbItem img').attr('src');
            $('.loading-modal').find('.product-title').html(title);
            $('.loading-modal').find('.product-image').attr('src', image);
            $('.loading-modal').find('.btn-wishlist').show();
            $('.loading-modal').css({"opacity": "1", "visibility": "initial", "transform": "translateX(0)", "transition": "all 0.3s"});
            $('.loading-modal').addClass('novload');
            setTimeout(function() {
                $('.loading-modal').css({"opacity": "0", "visibility": "hidden", "transform": "translateX(410px)", "transition": "all 0.3s"});
                $('.loading-modal').removeClass('novload');
            }, 5000);

            if ($('[data-wishlist-container]').length) {
                novtheme.createNovWishListTplItem(ProductHandle);
            };

            wishListsArr.push(ProductHandle);
            localStorage.setItem('wishListsArr', JSON.stringify(wishListsArr));

        } else {
            self.removeClass('whislist-added');
            self.find('.wishlist-text').text('Add To WishList');

            
            if ($('[data-wishlist-added="wishlist-'+productId+'"]').length) {
                $('[data-wishlist-added="wishlist-'+productId+'"]').remove();
            }

            wishListsArr.splice(idxArr, 1);
            localStorage.setItem('wishListsArr', JSON.stringify(wishListsArr));
        };

        novtheme.setNovAddedForWishlistIcon(ProductHandle);
    });
};
novtheme.createNovWishListTplItem = function(ProductHandle) {
  var wishListCotainer = $('[data-wishlist-container]');

  jQuery.getJSON(window.router + '/products/'+ProductHandle+'.js', function(product) {
    var productHTML = '',
        price_min = Shopify.formatMoney(product.price_min, "$");

        productHTML += '<div class="grid-item" data-wishlist-added="wishlist-'+product.id+'">';
        productHTML += '<div class="inner item-product row align-items-center" data-product-id="product-'+product.handle+'">';
        productHTML += '<div class="column_content col-xl-5 col-lg-5 col-md-4 col-sm-12 col-xs-12"><div class="product-image">';
        productHTML +='<a href="'+product.url+'" class="product-grid-image" data-collections-related="/collections/all?view=related">';
        productHTML += '<img src="'+product.featured_image+'" alt="'+product.featured_image.alt+'">';
        productHTML += '</a></div>';
        productHTML += '<div class="product-info">';
        productHTML += '<div class="product-title">';
        productHTML += '<a href="'+product.url+'" title="'+product.title+'">'+product.title+'</a></div></div>';
        productHTML += '<div class="column_content col-xl-3 col-lg-3 col-md-2 col-sm-12 col-xs-12 text-center"><div class="price-box">'+ price_min +'</div></div>';
        productHTML += '<div class="column_content col-xl-2 col-lg-2 col-md-3 col-sm-12 col-xs-12 text-center"><a class="btn whislist-added" href="#" data-product-handle="'+ product.handle +'" data-icon-wishlist data-id="'+ product.id +'"><i class="fa fa-trash-o" aria-hidden="true"><i class="fa fa-trash-o" aria-hidden="true"></i>translation missing: en.products.product.remove</a></div>';
        productHTML += '<div class="column_content col-xl-2 col-lg-2 col-md-3 col-sm-12 col-xs-12 text-center">';
        productHTML += '<form action="/cart/add" method="post" class="variants formAddToCart" id="-'+product.id+'" data-id="product-actions-'+product.id+'" enctype="multipart/form-data">';

    if (product.available) {
        if (product.variants.length == 1) {
            productHTML += '<button class="btn btnAddToCart" type="submit" data-form-id="#-'+product.id+'" ><span>Add to cart</span><span>Add to cart</span></button><input type="hidden" name="id" value="'+ product.variants[0].id +'" />'; 
        } 
        if (product.variants.length > 1){
            productHTML += '<a class="btn btnAddToCart" title="'+product.title+'" href="'+product.url +'"><i class="zmdi zmdi-check"></i><span>Select Options</span></a>';
        }
    }
    else {
        productHTML += '<button class="btn btnAddToCart" type="button" disabled="disabled">Unavailable</button>';
    } 

    productHTML += '</form></div>';

    productHTML += '</div></div>';

    wishListCotainer.append(productHTML);
  });
};
novtheme.popupCart = function(e) {
    $(document).on('click', '.popupCartClose', function(e) {
        e.preventDefault();
        $("#popup-Cart .jsPopupview").html('');
        $('#popup-Cart').modal('toggle');
    });
};
novtheme.click_button_canvas_menu = function() {
    $('#show-megamenu').on("click", function() {
        if ($('.canvas-menu').hasClass('active')) {
            $('.canvas-menu').removeClass('active');
            $('body').removeClass('canvasmenu-right');
            $(this).removeClass('close');
        } else {
            $('.canvas-menu').addClass('active');
            $('body').addClass('canvasmenu-right');
            $(this).addClass('close');
        }
        return false;
    });
};
novtheme.load_canvas_menu = function() {
    var $main_menu = $(".site-nav", "#AccessibleNav");
    if (current_width < 768) {
        if ($("#canvas-main-menu").length < 1 && $main_menu.length > 0) {
            var $menu = $main_menu.parent().clone();
            $menu.attr("id", "canvas-main-menu");
            $($menu).find(".menu").removeAttr('id');
            $('.canvas-menu').append($menu);
            $menu.mmenu({
                offCanvas: false,
                "navbar": {
                    "title": false
                }
            });
            novtheme.remove_canvas_menu();
        }
        $('.mm-next').click(function(){
            $('.navmenu-product .grid--view-items').slick('refresh');
        })
    }
};
novtheme.remove_canvas_menu = function() {
    $('.canvas-header-box .close-box, .canvas-overlay').on("click", function() {
        $('.canvas-menu').removeClass('active');
        $('body').removeClass('canvasmenu-right');
        return false;
    });
};
novtheme.NoneThumbnailProductDetail = function() {
    if ($('html').hasClass('lang-rtl'))
        rtl = true;
    else
        rtl = false;
    var autoplay = $("#productThumbs .owl-carousel").data('autoplay');
    var autoplaytimeout = $("#productThumbs .owl-carousel").data('autoplaytimeout');
    var items = $("#productThumbs .owl-carousel").data('items');
    var margin = $("#productThumbs .owl-carousel").data('margin');
    var nav = $("#productThumbs .owl-carousel").data('nav');
    var dots = $("#productThumbs .owl-carousel").data('dots');
    var loop = $("#productThumbs .owl-carousel").data('loop');
    var items_tablet = $("#productThumbs .owl-carousel").data('items_tablet') ? $("#productThumbs .owl-carousel").data('items_tablet') : 3;
    var items_mobile = $("#productThumbs .owl-carousel").data('items_mobile') ? $("#productThumbs .owl-carousel").data('items_mobile') : 1;
    var center = $("#productThumbs .owl-carousel").data('center') ? $("#productThumbs .owl-carousel").data('center') : false;
    var start = $("#productThumbs .owl-carousel").data('start') ? $("#productThumbs .owl-carousel").data('start') : 0;
    $("#productThumbs .owl-carousel").owlCarousel({
        navText: ['<i class="fa fa-long-arrow-left"></i>', '<i class="fa fa-long-arrow-right"></i>'],
        lazyLoad: true,
        lazyContent: true,
        loop: loop,
        autoplay: autoplay,
        autoplayTimeout: autoplaytimeout,
        items: items,
        margin: margin,
        rtl: rtl,
        dots: dots,
        nav: nav,
        center: center,
        responsive: {
            0: {
                items: 1,
                center: center,
                margin: 0
            },
            576: {
                items: items_mobile,
                center: center,
                margin: 10
            },
            768: {
                items: items_tablet,
                margin: 10
            },
            992: {
                items: items,
                margin: margin
            },
            1200: {
                items: items,
                startPosition: start,
                margin: margin
            },
        }
    });
};
novtheme.VerticalThumbnailProductDetail= function() {
    if ($('html').hasClass('lang-rtl'))
        var rtl = true
    else
        var rtl = false
    $('.thumb_vertical_slick').slick({
        nextArrow: '<div class="arrow-next"><i class="zmdi zmdi-chevron-down"></i></div>',
        prevArrow: '<div class="arrow-prev"><i class="zmdi zmdi-chevron-up"></i></div>',
        infinite: false,
        slidesToShow: 5,
        slidesToScroll: 5,
        vertical: true,
        verticalSwiping: true,
        arrows: false,
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 4,
                arrows: false
            }
        }, {
            breakpoint: 992,
            settings: {
                arrows: false,
                slidesToShow: 4,
                slidesToScroll: 4
            }
        }, {
            breakpoint: 768,
            settings: {
                vertical: false,
                verticalSwiping: false,
                arrows: false,
                slidesToShow: 4,
                slidesToScroll: 4
            }
        }, {
            breakpoint: 480,
            settings: {
                vertical: false,
                verticalSwiping: false,
                arrows: false,
                slidesToShow: 3,
                slidesToScroll: 3
            }
        }]
    });
    if ($(window).width() > 991 && $('.template-product').length > 0 ) {
        $(window).on('mousewheel DOMMouseScroll wheel', (function(e) {
            $('.thumb_vertical .proFeaturedImage .item.act').each(function(){
                var item = $(this),
                    p = item.data('position'),
                    hd = item.height()/2,
                    hu = item.height() -150,
                    srt = $(window).scrollTop(),
                    y = e.originalEvent.deltaY,
                    offset_top = item.offset().top;
                if (y > 0) {
                    if (p < $('.proFeaturedImage .item').length) {
                        var npd = p + 1;
                    } else {
                        var npd = p;
                    }
                    if (srt > offset_top + hd) {
                       item.removeClass('act');
                       $('.proFeaturedImage .item[data-position="'+ npd +'"]').addClass('act');
                       $('.thumbItem[data-position="'+ p +'"]').removeClass('active');
                       $('.thumbItem[data-position="'+ npd +'"]').addClass('active');
                    } 
                } else {
                    if (p > 1) {
                        var npu = p - 1;
                    } else {
                        var npu = p;
                    }
                    if (srt < offset_top - hd) {
                        item.removeClass('act');
                        $('.proFeaturedImage .item[data-position="'+ npu +'"]').addClass('act');
                        $('.thumbItem[data-position="'+ p +'"]').removeClass('active');
                        $('.thumbItem[data-position="'+ npu +'"]').addClass('active');
                    }
                }
            });
        }));
        $('.product-thumb_vertical .thumbItem').click(function(){
            var p = $(this).data('position');
            $('.product-thumb_vertical .thumbItem').removeClass('active');
            $(this).addClass('active');
            $('.proFeaturedImage .item').removeClass('act');
            $('.proFeaturedImage .item[data-position="'+ p +'"]').addClass('act');
            var ost = $('.proFeaturedImage .item.act').offset().top;
            $("body,html").animate({scrollTop: ost - 30}, "normal");
        });
    }
    if ($(window).width() < 992 ) {
        if($(document).width() <= 991 ) {
            $('.thumb_vertical .proFeaturedImage').slick({
                slide: '.item',
                infinite: false,
                slidesToShow: 1,
                slidesToScroll: 1,
                adaptiveHeight: true,
            }).on('afterChange',function(e,o){
                $('iframe').each(function(){
                    $(this)[0].contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');
                });
                $('video').trigger('pause');
            });
            $('.thumb_vertical .proFeaturedImage').on('afterChange', function(event, slick, currentSlide) {
                $('#productThumbs .thumb_vertical_slick').slick('slickGoTo', currentSlide);
                $('#productThumbs .thumb_vertical_slick').find('.slick-slide.item-active').removeClass('item-active');
                $('#productThumbs .thumb_vertical_slick').find('.slick-slide[data-slick-index="' + currentSlide + '"]').addClass('item-active');
            });

            $('.thumb_vertical .thumb_vertical_slick').on('click', '.slick-slide', function(event) {
                event.preventDefault();
                var goToSingleSlide = $(this).data('slick-index');
                $('.thumb_vertical .proFeaturedImage').slick('slickGoTo', goToSingleSlide);
            });
        };
    }
};
novtheme.ThumbnailProductDetail = function() {
    var $FeaturedImage = $('.FeaturedImage_slick');
    var $ThumbImage = $('#productThumbs .thumb_slick');
    if ($('html').hasClass('lang-rtl'))
        var rtl = true;
    else
        var rtl = false;
    $FeaturedImage.slick({
        slide: '.item',
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: false,
        adaptiveHeight: true,
        infinite: false,
        useTransform: true,
        speed: 400,
        cssEase: 'cubic-bezier(0.77, 0, 0.18, 1)',
        rtl: rtl,
    });

    var autoplay = $ThumbImage.data("autoplay"),
        autoplaytimeout = $ThumbImage.data("autoplaytimeout"),
        infinite = $ThumbImage.data("loop"),
        dots = $ThumbImage.data("dots"),
        nav = $ThumbImage.data("nav"),
        loop = $ThumbImage.data('loop'),
        fade = $ThumbImage.data("fade"),
        vertical = $ThumbImage.data("vertical"),
        verticalSwiping = $ThumbImage.data("vertical"),
        items = $ThumbImage.data("items"),
        items_lg = $ThumbImage.data("items_lg"),
        items_md = $ThumbImage.data("items_md"),
        items_sm = $ThumbImage.data("items_sm"),
        items_xs = $ThumbImage.data("items_xs");
    $ThumbImage.on('init', function(event, slick) {
        $(this).find('.slick-slide.slick-current').addClass('active');
    })
    .slick({
        slide: '.item',
        infinite: infinite,
        slidesToShow: items,
        slidesToScroll: 2,
        dots: dots,
        arrows: nav,
        rtl: rtl,
        vertical: vertical,
        verticalSwiping: verticalSwiping,
        focusOnSelect: false,
        responsive: [
        {
            breakpoint: 1920,
            settings: {
                slidesToShow: items,
                slidesToScroll: items
            }
        },
        {
            breakpoint: 1200,
            settings: {
                slidesToShow: items_lg,
                slidesToScroll: items_lg
            }
        },
        {
            breakpoint: 992,
            settings: {
                slidesToShow: items_md,
                slidesToScroll: items_md
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: items_sm,
                slidesToScroll: items_sm,
                verticalSwiping: false
            }
        },
        {
            breakpoint: 576,
            settings: {
                slidesToShow: items_xs,
                slidesToScroll: items_xs,
                vertical: false,
                verticalSwiping: false
            }
        }
        ]
    });

    $FeaturedImage.on('afterChange', function(event, slick, currentSlide) {
        $ThumbImage.slick('slickGoTo', currentSlide);
        $ThumbImage.find('.slick-slide.active').removeClass('active');
        $ThumbImage.find('.slick-slide[data-slick-index="' + currentSlide + '"]').addClass('active');
        $('iframe').each(function(){
            $(this)[0].contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');
        });
        $('video').trigger('pause');
        // Type thumb all
        $('.thumb_all .thumbItem').removeClass('active');
        $('.thumb_all .thumbItem[data-position="' + currentSlide + '"]').addClass('active');
    });

    $ThumbImage.on('click', '.slick-slide', function(event) {
        event.preventDefault();
        var goToSingleSlide = $(this).data('slick-index');
        $FeaturedImage.slick('slickGoTo', goToSingleSlide);
    });
    // Type thumb all
    $('.thumb_all .thumbItem').on('click', function(event) {
        event.preventDefault();
        var position = $(this).data('position');
        $FeaturedImage.slick('slickGoTo', position);
    });    
};
novtheme.RelatedBlog = function() {
    if ($('html').hasClass('lang-rtl'))
        rtl = true;
    else
        rtl = false;
    var $this = $('.BlogRelated .owl-carousel');
    var autoplay = $($this).data('autoplay');
    var autoplaytimeout = $($this).data('autoplaytimeout');
    var items = $($this).data('items');
    var margin = $($this).data('margin');
    var nav = $($this).data('nav');
    var dots = $($this).data('dots');
    var loop = $($this).data('loop');
    var items_tablet = $($this).data('items_tablet') ? $($this).data('items_tablet') : 3;
    var items_mobile = $($this).data('items_mobile') ? $($this).data('items_mobile') : 1;
    var center = $($this).data('center') ? $($this).data('center') : false;
    var start = $($this).data('start') ? $($this).data('start') : 0;
    $($this).owlCarousel({
        navText: ['<i class="fa fa-long-arrow-left"></i>', '<i class="fa fa-long-arrow-right"></i>'],
        lazyLoad: true,
        lazyContent: true,
        loop: loop,
        autoplay: autoplay,
        autoplayTimeout: autoplaytimeout,
        items: items,
        margin: margin,
        rtl: rtl,
        dots: dots,
        nav: nav,
        responsive: {
            0: {
                items: items_mobile,
                center: center,
                margin: 10
            },
            768: {
                items: items_tablet,
                margin: 10
            },
            992: {
                items: items,
                margin: margin
            },
            1200: {
                items: items,
                startPosition: start,
                margin: margin
            },
        }
    });
};
novtheme.RelatedProduct = function() {
    if ($('html').hasClass('lang-rtl'))
        rtl = true;
    else
        rtl = false;
    var $this = $('.owl-relatedproduct');
    var autoplay = $($this).data('autoplay');
    var autoplayTimeout = $($this).data('autoplayTimeout');
    var items = $($this).data('items');
    var margin = $($this).data('margin');
    var nav = $($this).data('nav');
    var dots = $($this).data('dots');
    var loop = $($this).data('loop');
    var items_tablet = $($this).data('items_tablet') ? $($this).data('items_tablet') : 3;
    var items_mobile = $($this).data('items_mobile') ? $($this).data('items_mobile') : 1;
    var center = $($this).data('center') ? $($this).data('center') : false;
    var start = $($this).data('start') ? $($this).data('start') : 0;
    $($this).owlCarousel({
        navText: ['<i class="zmdi zmdi-chevron-left"></i>', '<i class="zmdi zmdi-chevron-right"></i>'],
        lazyLoad: true,
        lazyContent: true,
        loop: loop,
        autoplay: autoplay,
        autoplayTimeout: autoplayTimeout,
        items: items,
        margin: margin,
        rtl: rtl,
        dots: dots,
        nav: nav,
        responsive: {
            0: {
                items: items_mobile,
                center: center,
                margin: 10
            },
            768: {
                items: items_tablet,
                margin: 10
            },
            992: {
                items: items,
                margin: margin
            },
            1200: {
                items: items,
                startPosition: start,
                margin: margin
            },
        }
    });
};
novtheme.callbackReview = function() {
    if ($(".shopify-product-reviews-badge").length > 0) {
        return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
    };
};
//Countdown
novtheme.Countdown = function() {
    $('[data-countdown]').each(function() {
        var $this = $(this), finalDate = $(this).data('countdown');
        $this.countdown(finalDate, function(event) {
            var totalHours = event.offset.totalDays * 24 + event.offset.hours;
            var countdown_format = '<div class="item-time"><span class="name-time">Hours</span><span class="data-number"><span>' + totalHours + '</span></span></div>'
                               + '<div class="item-time"><span class="name-time">Mins</span><span class="data-number"><span>%M</span></span></div>'
                               + '<div class="item-time"><span class="name-time">Secs</span><span class="data-number"><span>%S</span></span></div>';
            $this.html(event.strftime(countdown_format));
        });
    });
};
novtheme.productPage = function(options) {
    var moneyFormat = options.money_format,
        variant = options.variant,
        selector = options.selector;
    var $productImage = $('#ProductPhotoImg'),
        $addToCart = $('#AddToCart'),
        $productPrice = $('#ProductPrice-nov-product-template'),
        $comparePrice = $('#ComparePrice-nov-product-template'),
        $quantityElements = $('.quantity-selector, label + .js-qty'),
        $quantity = $('.product-form__item--quantity'),
        $addToCartText = $('#AddToCartText');
    if (variant) {
        var form = $('#' + selector.domIdPrefix).parents('form');
        for (var i = 0, length = variant.options.length; i < length; i++) {
            var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] + '"]');
            if (radioButton.length > 0) {
                radioButton.get(0).checked = true;
            }
        }
        if (variant.featured_image) {
            var newImage = variant.featured_image;
            var element = $productImage[0];
            Shopify.Image.switchImage(newImage, element, function(src, imgObject, el) {
                $('.thumblist img').each(function() {
                    var idProductImage = $(this).parent().data('image');
                    if (idProductImage == src) {
                        $(this).parent().trigger('click');
                        var position = $(this).parents('.owl-item').index();
                        $('.thumblist .owl-carousel').trigger('to.owl.carousel', position);
                        return false;
                    }
                });
            });
        }
        if (variant.available) {
            var d_qty = $('#productSelect :selected').data('qty');
            if (d_qty < 1) {
                $addToCartText.html("Pre - Order");
            } else {
                $addToCartText.html("Add to cart");
            }
            $addToCart.removeClass('disabled').prop('disabled', false);
            $quantity.show();
            $addToCart.removeClass('disabled').prop('disabled', false);
            $quantityElements.show();
            $('.group-quantity .control-label').show();
            $('.group-quantity').css('margin-top', '0');
            $('input').parent('.swatch-element').find('.sold').hide();
        } else {
            $quantity.hide();
            $addToCart.addClass('disabled').prop('disabled', true);
            $addToCartText.html("Notify Me");
            $quantityElements.hide();
            $('input:not(:checked)').parent('.swatch-element').find('.sold').hide();
            $('input:checked').parent('.swatch-element').find('.sold').show();
            $('input:checked').parent('.swatch-element').attr('data-toggle', 'modal');
            $('.group-quantity .control-label').hide();
            $('.group-quantity').css('margin-top', '30px');
        }
        $productPrice.html(theme.Currency.formatMoney(variant.price, moneyFormat));
        if (variant.compare_at_price > variant.price) {
            $comparePrice.html(theme.Currency.formatMoney(variant.compare_at_price, moneyFormat)).show();
        } else {
            $comparePrice.hide();
        }
        if ($('#currencies').length != 0) {
            Currency.convertAll(shopCurrency, $('#currencies span.selected').attr('data-currency'));
        }
    } else {
        $quantity.removeClass('d-block');
        $addToCart.addClass('disabled').prop('disabled', true);
        $addToCartText.html("Unavailable");
        $quantityElements.hide();
    }
};
novtheme.productImageSwitch = function() {
    if (novtheme.cache.$thumbImages.length) {
        $('.thumbItem').each(function() {
            var srcproFeatured = $('#ProductPhotoImg').attr('src');
            var srcthumnail = $('.product-single__thumbnail', this).attr('data-image');
            if (srcproFeatured == srcthumnail) {
                $(this).addClass('active');
            };
        });
        novtheme.cache.$thumbImages.on('click', function(evt) {
            evt.preventDefault();
            var newImage = $(this).attr('data-image');
            $('.thumbItem').removeClass('active');
            $(this).parent().addClass('active');
            novtheme.switchImage(newImage, null, novtheme.cache.$productImage);
            //$('.zoomImg').attr('src', newImage);
        });
        $('variant-radios label').click(function () {
            setTimeout(function() {
                var dindex = $('.FeaturedImage_slick').find('.item.act').attr('data-slick-index');
                $('.FeaturedImage_slick').slick('slickGoTo', dindex);
            }, 300);
        })
    }
};
novtheme.switchImage = function(src, imgObject, el) {
    var $el = $(el);
    $el.attr('src', src);
};
novtheme.cacheSelectors = function() {
    novtheme.cache = {
        $html: $('html'),
        $body: $(document.body),
        $navigation: $('#AccessibleNav'),
        $mobileSubNavToggle: $('.mobile-nav__toggle'),
        $changeView: $('.change-view'),
        $productImage: $('#ProductPhotoImg'),
        $thumbImages: $('.product-template__container:not(.thumb_grid) #productThumbs').find('a.product-single__thumbnail'),
        $thumbItem: $('.thumb_grid').find('.thumbItem'),
        
        $recoverPasswordLink: $('#RecoverPassword'),
        $hideRecoverPasswordLink: $('#HideRecoverPasswordLink'),
        $recoverPasswordForm: $('#RecoverPasswordForm'),

        $recoverPasswordIndex: $('#RecoverPasswordIndex'),
        $hideRecoverPasswordIndex: $('#HideRecoverPasswordIndex'),
        $recoverPasswordFormIndex: $('#RecoverPasswordFormIndex'),

        $customerLoginForm: $('#CustomerLoginForm'),
        $passwordResetSuccess: $('#ResetSuccess')
    };
};
novtheme.eventBlockCart = function(e) {
    if($(document).width() > 767 ) {
        $('.cart_canvas .header-cart').click(function(){
            $(".sidebar-overlay").addClass('act');
            $("#_desktop_cart").addClass('active');
        });
        $('.close_cart').click(function(){
            $(".sidebar-overlay").removeClass('act');
            $('#_desktop_cart').removeClass('active')
        });
    }

    // Hover Cart
    if (!('ontouchstart' in document)) {
        $('.cart_dropdown .header-cart').hover(function() {
            if (!$('.cart_dropdown #cart-info').is(':visible')) {
                $(".cart_dropdown #cart-info").slideDown('fast');
            }
        });
        $('.cart_dropdown #cart_block').mouseleave(function() {
            $(".cart_dropdown #cart-info").slideUp('fast');
        });
    } else {
        //tablet
        $('.cart_dropdown .header-cart').click(function() {
            if ($('.cart_dropdown #cart-info').is(':visible')) {
                $(".cart_dropdown #cart-info").slideUp('fast');
            } else {
                $(".cart_dropdown #cart-info").slideDown('fast');
            }
        });
    }
};
novtheme.eventAccountCanvas = function(e) {
    if($(document).width() > 767 ) {
        $('.account_canvas').click(function(){
            $(".sidebar-overlay").addClass('act');
            $(".block_account_canvas").addClass('active');
        });
        $('.close_account').click(function(){
            $(".sidebar-overlay").removeClass('act');
            $('.block_account_canvas').removeClass('active')
        });
    }
};
novtheme.NovToggleSearch = function() {
    $('.search-toggle').on('click.break', function(event) {
        $('.site-header__search').toggleClass('open');
        $('.search-bar__form .search-bar__input').focus();
        $('.sidebar-overlay').addClass('act');

    });
    $('.bl_close').click(function () {
        $('.site-header__search').removeClass('open');
        $('.sidebar-overlay').removeClass('act');
    })
};
novtheme.NovTogglePage = function() {
    $('.nov-toggle-page').on('click', function(e) {
        var target = $(this).data('target');
        $('body').hasClass('show-boxpage') ? ($('body').removeClass('show-boxpage')) : ($('body').addClass('show-boxpage'));
        $(target).hasClass('active') ? ($(target).removeClass('active')) : ($(target).addClass('active'));
        e.preventDefault();
    });
    $('.box-header .close-box').on('click', function(e) {
        $('body').removeClass('show-boxpage');
        $(this).parents('.mobile-boxpage').removeClass('active');
        $('.back-box', '#mobile-pageaccount').removeClass('active');
        $('#mobile-pageaccount').find('.box-content').removeClass('active');
        e.preventDefault();
    });
    $('.links-currency, .links-language').on('click', function(e) {
        var target_link = $(this).data('target'),
            title_box = $(this).data('titlebox');
        $('#mobile-pageaccount').find('.box-content').removeClass('active');
        $('.title-box', '#mobile-pageaccount').html(title_box);
        $('.back-box', '#mobile-pageaccount').addClass('active');
        $(target_link).hasClass('active') ? ($(target_link).removeClass('active')) : ($(target_link).addClass('active'));
        e.preventDefault();
    });
    $('.back-box', '#mobile-pageaccount').on('click', function(e) {
        var titlebox_parent = $('#mobile-pageaccount').data('titlebox-parent');
        $('#mobile-pageaccount').find('.box-content').removeClass('active');
        $('.title-box', '#mobile-pageaccount').html(titlebox_parent);
        $(this).removeClass('active');
        e.preventDefault();
    })
};
novtheme.NovHeightBoxContent = function() {
    var height = $(window).outerHeight(),
        boxheight = $('.box-header').outerHeight(),
        menubottom = $('#stickymenu_bottom_mobile').outerHeight();
    $('.box-content', '.mobile-boxpage').each(function() {
        $(this).outerHeight(height - 45);
    });
};
novtheme.NovEventClickSearchMobile = function() {
    $('#stickymenu_bottom_mobile .js-btn-search').click(function() {
        $('#mobile_search .search-header__input').focus();
        $("body,html").animate({
            scrollTop: 0
        }, "normal");
    })
};
novtheme.goToTop = function() {
    var timer;
    $(window).scroll(function () {
        if (timer)
            clearTimeout(timer)
        timer = setTimeout(function () {
            if ($(window).scrollTop() >= 200) {
                $('#_desktop_back_top').fadeIn();
            } else {
                $('_desktop_back_top').fadeOut();
            }
        }, 300);

    });
    $("#_desktop_back_top").click(function () {
        $("body,html").animate({scrollTop: 0}, "normal");
        return!1
    });
};
novtheme.goToTopMobile = function() {
    if ($(window).width() < 768) {
        var timer;
        $(window).scroll(function() {
            if (timer) clearTimeout(timer)
            timer = setTimeout(function() {
                $('#back_top').fadeIn();
            }, 200);
        });
        $("#back_top").click(function() {
            $("body,html").animate({
                scrollTop: 0
            }, "normal");
            return !1
        });
    }
};
novtheme.PopupNewletter = function() {
    var date = new Date();
    var minutes = 60;
    date.setTime(date.getTime() + (minutes * 60 * 1000));
    if ($.cookie('popupNewLetterStatus') != 'closed' && $('body').outerWidth() > 768) {
        $("#popup-subscribe").modal({
            show: !0
        });
    }
    $.cookie("popupNewLetterStatus", "closed", {
        'expires': date,
        'path': '/'
    })
    $('input.no-view').change(function() {
        if ($('input.no-view').prop("checked") == 1) {
            $.cookie("popupNewLetterStatus", "closed", {
                'expires': date,
                'path': '/'
            })
        } else {
            $.cookie("popupNewLetterStatus", "", {
                'expires': date,
                'path': '/'
            })
        }
    })
};
novtheme.variantName = function() {
    if ($('.template-product .thumb_grid').length > 0) {
        var val = $('.swatch[data-option-index="0"] .swatch-element input:checked').parent().data('value');
        $('.thumbItem[data-variant="'+val+'"]').addClass('show');
        
        $('.swatch[data-option-index="0"] .swatch-element label').on('click', function() {
            var value = $(this).parent().data('value');
            $('.thumbItem').removeClass('show');
            $('.thumbItem[data-variant="'+value+'"]').addClass('show');
        }); 
    }
};
novtheme.MenuSidebar = function() {
    $('.categories__sidebar .hasSubCategory a').each(function(index) {
        if ($(this).hasClass('active')) {
            $(this).parent().children('.collapse').collapse('show');
        }
    })
};
//NOV-IFRAME_VIDEO
novtheme.Nov_iframe_video = function() {
    var $videoSrc; 
    $('.icon_play').click(function() {
        $videoSrc = $(this).data( "src" );
    });
    $('#ModalVideo').on('shown.bs.modal', function (e) {
        
    $('#video').attr('src',$videoSrc ); 
    })
    $('#ModalVideo').on('hide.bs.modal', function (e) {
        // a poor man's stop video
        $('#video').attr('src',$videoSrc); 
    })
};
novtheme.MegaMenuSlider = function() {
    if ($('html').hasClass('lang-rtl'))
        var rtl = true;
    else
        var rtl = false;
    var autoplay = $(".navmenu-product .grid--view-items").data("autoplay"),
        dots = $(".navmenu-product .grid--view-items").data("dots");
    $('.navmenu-product .grid--view-items').slick({
        autoplay: autoplay,
        autoplaySpeed: 2000,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: dots,
        arrows: false,
        rtl: rtl,
    });
};
novtheme.SliderSyncing = function() {
    if ($('html').hasClass('lang-rtl'))
        var rtl = true;
    else
        var rtl = false;
    var arrows = $(".nov-slick-for").data('nav');
    var dots = $(".nov-slick-for").data('dots');
    $('.nov-slick-for').slick({
        nextArrow: '<div class="arrow-next"><i class="zmdi zmdi-long-arrow-right"></i></div>',
        prevArrow: '<div class="arrow-prev"><i class="zmdi zmdi-long-arrow-left"></i></div>',
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: arrows,
        dots: dots,
        asNavFor: '.nov-slick-nav',
        rtl: rtl
    });
    $('.nov-slick-nav').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        dots: false,
        asNavFor: '.nov-slick-for',
        rtl: rtl
    });
};
novtheme.SlideshowDealsSlick = function() {
    $(".slideshow__deals-slider").each(function (index) {
        if ($('html').hasClass('lang-rtl'))
            rtl = true;
        else
            rtl = false;
        $(this).slick({
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true,
            arrows: false,
            rtl: rtl,
            responsive: [
                {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        verticalSwiping: false
                    }
                },
                {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        vertical: false,
                        verticalSwiping: false
                    }
                }
            ]
        });
    })
};
novtheme.Vertical = function() {
    /*if ($(document).width() > 1199) {
        $('.vertical_menu li.site-nav--has-dropdown').each(function(){
            var $menuItem = $(this),
                $submenuWrapper = $('> .site-nav__dropdown', $menuItem),
                menuItemPos = $menuItem.position();
            $submenuWrapper.css({
                top: menuItemPos.top,
                left: menuItemPos.left + $menuItem.outerWidth() + 20,
                opacity: 0,
                visibility: "hidden"
            });
            $menuItem.hover(function() {
                $submenuWrapper.css({
                    left: menuItemPos.left + $menuItem.outerWidth(),
                    opacity: 1,
                    visibility: "visible"
                });
                }, function(){
                $submenuWrapper.css({
                    left: menuItemPos.left + $menuItem.outerWidth() + 20,
                    opacity: 0,
                    visibility: "hidden"
                });
            });
        })
    }*/
    if ($(document).width() < 1200) {
        $('.vertical_menu .site-nav__link--main >.show_sub').click(function(e){
            $(this).parent().each(function(){
                e.preventDefault();
            });
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).parent().parent('.site-nav--has-dropdown').children('.site-nav__dropdown').slideUp(300);
            } else {
                $('.vertical_menu .show_sub').removeClass('active');
                $('.vertical_menu .site-nav__dropdown').slideUp(300);
                $(this).addClass('active').parent().parent('.site-nav--has-dropdown').children('.site-nav__dropdown').slideDown(300);
            }
        });
        $('.vertical_menu  .nav-children-has-dropdown .site-nav__child-link--parent').click(function(e){
            e.preventDefault();
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).parent().find('.site-nav__dropdown-children').slideUp(300);
            } else {
                $('.site-nav__dropdown-children').slideUp(300);
                $('.site-nav__child-link--parent').removeClass('active');
                $(this).addClass('active');
                $(this).parent().find('.site-nav__dropdown-children').slideDown(300);
            }
        });
    }

    $('.btn_ver').click(function(){
        if($(document).width() < 992 ) {
            $("#_desktop_vertical_menu").addClass('active');
            $(".sidebar-overlay").addClass('act');
        }
        if($(document).width() < 768 ) {
            $("#_mobile_vertical_menu").addClass('active');
            $(".sidebar-overlay").addClass('act');
        }
    });

};
novtheme.Mainmenu = function() {
    if($(document).width() > 767 ) {
        // Show sub menu canvas
        $('#AccessibleNav .site-nav--has-dropdown .site-nav__link--main').click(function(e){
            e.preventDefault();
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).parent().find('.site-nav__dropdown').slideUp(300);
                $(this).find('.show_sub i').addClass('zmdi-chevron-down').removeClass('zmdi-chevron-up');
            } else {
                $('#AccessibleNav .site-nav__dropdown').slideUp(300);
                $('#AccessibleNav .site-nav__link--main').removeClass('active');
                $(this).addClass('active');
                $(this).parent().find('.site-nav__dropdown').slideDown(300);
            }
        });

        // Show sub children menu canvas
        $('#AccessibleNav .nav-children-has-dropdown .site-nav__child-link--parent').click(function(e){
            e.preventDefault();
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).parent().find('.site-nav__dropdown-children').slideUp(300);
            } else {
                $('.site-nav__dropdown-children').slideUp(300);
                $('.site-nav__child-link--parent').removeClass('active');
                $(this).addClass('active');
                $(this).parent().find('.site-nav__dropdown-children').slideDown(300);
            }
        });
    }
};
novtheme.LoadmoreByButton = function(){
    var moreButon =  $('.btn_loadmore');
    var data = $(moreButon).parents('.grid--view-items'),
        xxl = $(data).data('xxl'),
        xl = $(data).data('xl'),
        lg = $(data).data('lg'),
        md = $(data).data('md'),
        sm = $(data).data('sm'),
        xs = $(data).data('xs');
    $(data).find('.item').each(function () {
        index = $(this).index() + 1;
        if($(document).width() > 1439 ) {
            var n = xxl;
        }
        if($(document).width() < 1440 && $(document).width() > 1199 ) {
            var n = xl;
        }
        if($(document).width() < 1200 && $(document).width() > 991 ) {
            var n = lg;
        }
        if($(document).width() < 992 && $(document).width() > 767 ) {
            var n = lg;
        }
        if($(document).width() < 768 && $(document).width() > 575 ) {
            var n = sm;
        }
        if($(document).width() < 576 ) {
            var n = xs;
        }
        var modulo = index % n * 0.3;
        $(this).attr('data-wow-duration', modulo+'s');
        if (index % n == 0) {
            var modulo0 = index % n + n *0.3;
            $(this).attr('data-wow-duration', modulo0+'s');
        } 
    });
    $(moreButon).each(function(){
        var btnHandle = $(this).attr('btn-handle');
        var nextUrl = $(this).attr("link");
        $('body').on('click', '.'+btnHandle+'', function(){
            $.ajax({
            url: nextUrl,
            type: 'GET',
            beforeSend: function() {
                $('.load-'+btnHandle).remove();
                $('.product__loadmore-'+btnHandle).parent().find('.loading').removeClass('hidden');
            }
            })
            .done(function(data) {
                $('.product__loadmore-'+btnHandle).parent().find('.loading').addClass('hidden');
                $('.product__loadmore-'+btnHandle).append($(data).find('.product__loadmore-'+btnHandle).html());
                var dataitem = $('.product__loadmore-'+btnHandle),
                    xxl = $(dataitem).data('xxl'),
                    xl = $(dataitem).data('xl'),
                    lg = $(dataitem).data('lg'),
                    md = $(dataitem).data('md'),
                    sm = $(dataitem).data('sm'),
                    xs = $(dataitem).data('xs');
                $(dataitem).find('.item').each(function () {
                    index = $(this).index() + 1;
                    if($(document).width() > 1439 ) {
                        var n = xxl;
                    }
                    if($(document).width() < 1440 && $(document).width() > 1199 ) {
                        var n = xl;
                    }
                    if($(document).width() < 1200 && $(document).width() > 991 ) {
                        var n = lg;
                    }
                    if($(document).width() < 992 && $(document).width() > 767 ) {
                        var n = lg;
                    }
                    if($(document).width() < 768 && $(document).width() > 575 ) {
                        var n = sm;
                    }
                    if($(document).width() < 576 ) {
                        var n = xs;
                    }
                    var modulo = index % n * 0.3;
                    $(this).attr('data-wow-duration', modulo+'s');
                    if (index % n == 0) {
                        var modulo0 = index % n + n *0.3;
                        $(this).attr('data-wow-duration', modulo0+'s');
                    } 
                })
                setTimeout(function () {
                    if ($('.shopify-product-reviews-badge').length && $('.spr-badge').length) {
                        return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
                    };
                }, 500);
                nextUrl = $(data).find('.btn_loadmore').attr("link");
            });
        });
    });
};
novtheme.CollectiontabLoadmore = function(){
    var LoadmoreBtn =  $('.collection_btn_loadmore');
    var data = $(LoadmoreBtn).parents('.grid--view-items'),
        xxl = $(data).data('xxl'),
        xl = $(data).data('xl'),
        lg = $(data).data('lg'),
        md = $(data).data('md'),
        sm = $(data).data('sm'),
        xs = $(data).data('xs');
    $(LoadmoreBtn).each(function(){
        var btnHandle = $(this).attr('btn-handle');
        var nextUrl = $(this).attr("link");
        $('body').on('click', '.'+btnHandle+'', function(){
            console.log($(this)); 
            $.ajax({
                url: nextUrl,
                type: 'GET',
                beforeSend: function() {
                    $('.load-'+btnHandle).remove();
                    $('.collection-loadmore-'+btnHandle).parent().find('.process-loading').addClass('active');
                }
            })
            .done(function(data) {
                $('.collection-loadmore-'+btnHandle).parent().find('.process-loading').removeClass('active');
                $('.collection-loadmore-'+btnHandle).append($(data).find('.collection-loadmore-'+btnHandle).html());
                var dataitem = $('.collection-loadmore-'+btnHandle),
                    xxl = $(dataitem).data('xxl'),
                    xl = $(dataitem).data('xl'),
                    lg = $(dataitem).data('lg'),
                    md = $(dataitem).data('md'),
                    sm = $(dataitem).data('sm'),
                    xs = $(dataitem).data('xs');
                $(dataitem).find('.item').each(function () {
                    index = $(this).index() + 1;
                    if($(document).width() > 1439 ) {
                        var n = xxl;
                    }
                    if($(document).width() < 1440 && $(document).width() > 1199 ) {
                        var n = xl;
                    }
                    if($(document).width() < 1200 && $(document).width() > 991 ) {
                        var n = lg;
                    }
                    if($(document).width() < 992 && $(document).width() > 767 ) {
                        var n = lg;
                    }
                    if($(document).width() < 768 && $(document).width() > 575 ) {
                        var n = sm;
                    }
                    if($(document).width() < 576 ) {
                        var n = xs;
                    }
                    var modulo = index % n * 0.3;
                    $(this).addClass('wow fadeInUp animated').attr('data-wow-duration', modulo+'s');
                    if (index % n == 0) {
                        var modulo0 = index % n + n *0.3;
                        $(this).attr('data-wow-duration', modulo0+'s');
                    } 
                })
                setTimeout(function () {
                    if ($('.shopify-product-reviews-badge').length && $('.spr-badge').length) {
                        return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
                    };
                }, 500);
                nextUrl = $(data).find('.btn_loadmore').attr("link");
            });
        });
    });
};
novtheme.CollectionPage = function() {
    if($(document).width() <768 ) {
        $('#main-collection-product-grid').attr('data-grid', 'grid-2');
        $('.gridlist-toggle a').removeClass('active');
        $('.gridlist-toggle #grid-2').addClass('active');
    }
    if (localStorage.getItem('view_collection')) {
       $('#main-collection-product-grid').attr('data-grid', localStorage.getItem('view_collection'));
       $('.gridlist-toggle a').removeClass('active');
       $('.gridlist-toggle [data-type="'+ localStorage.getItem('view_collection') +'"]').addClass('active');
    }
    $('.gridlist-toggle a').click(function(e) {
        e.preventDefault();
        var typeview = $(this).data('type');
        if (!$(this).hasClass('active')) {
            $('#main-collection-product-grid').attr('data-grid', typeview);
            $('.gridlist-toggle a').removeClass('active');
            $(this).addClass('active');
        }
        localStorage.setItem('view_collection', $('#main-collection-product-grid').attr('data-grid'));
    });

    $('.filter_button').click(function(e){
        $('.sidebar-filter').addClass('active');
        $('.sidebar-overlay').addClass('act');
    });
};
novtheme.BlockCanvasRight = function() {
    $('.btn_canvas').click(function(){
        $('#BlockCanvansRight').addClass('act');
    });
    $('.close-canvas-right').click(function(){
        $('#BlockCanvansRight').removeClass('act');
    })
};
novtheme.CanvasIndexLeft = function() {
    $('.btn_index-left').click(function(){
        $('#index__left').addClass('act');
        $('.sidebar-overlay').addClass('act');
    });
};
$(document).ready(function() {
    var d = $(this),
        mobile = false;
    $(novtheme.init);
    if (responsive_mobile) {
        novtheme.toggleMobileStyles();
    }
    if ($("#popup-subscribe").length) {
        $(window).on('load', function() {
            var timer = window.setTimeout(novtheme.PopupNewletter(), 2000);
        });
    }
    if ($("#popupAlert").length) {
        $(window).on('load', function() {
            $('#popupAlert').modal();
        });
    }
    $(window).on('resize', function() {
        if (d.width() <= 980 && mobile == false) {
            mobile = true;
        } else if (d.width() > 980) {
            mobile = false;
        }
    });
    
    // Change image product item
    $(".product-swatch-color a").click(function(e){
        e.preventDefault();
        var data_image_variant = $(this).data('image-variant');
        var src_img = $(this).parents('.item-product').find('.product__thumbnail');
        src_img.attr('srcset', data_image_variant);
        $(this).parents('.item-product').find(".product-swatch-color a").removeClass('active');
        $(this).parents('.item-product').find(".product__thumbnail-second").hide();
        $(this).addClass('active');
    });

    $(".sidebar-overlay").click(function() {
        $(this).removeClass('act');
        $('.sidebar-filter').removeClass('active');
        $("#_desktop_cart").removeClass('active');
        $('#AccessibleNav').removeClass('active');
        $('.block_account_canvas').removeClass('active');
        $('body').removeClass('canvas-menu-respon');
        $('#index__left').removeClass('act');
        $('#_mobile_vertical_menu').removeClass('active');
    });
    novtheme.HideShowPassword = function() {
        $('.hide_show_password').show();
        $('.hide_show_password span').addClass('show')
          
        $('.hide_show_password span').click(function(){
            if( $(this).hasClass('show')) {
                $(this).html('<i class="zmdi zmdi-eye"></i>');
                $('input[name="customer[password]"]').attr('type','text');
                $(this).removeClass('show');
            } else {
                $(this).html('<i class="zmdi zmdi-eye-off"></i>');
                $('input[name="customer[password]"]').attr('type','password');
                $(this).addClass('show');
            }
        });
            
        $('form button[type="submit"]').on('click', function(){
            $('.hide_show_password span').text('Show').addClass('show');
            $('.hide_show_password').parent().find('input[name="customer[password]"]').attr('type','password');
        });
    }

    // Toggle Search
    novtheme.NovSearchToggle = function() {
        $('.search-button').on("click", function(e) {
            $(this).parent(".site-header__search").hasClass("search-active") ? ($(this).parent(".site-header__search").removeClass('search-active')) : ($(this).hide().parent(".site-header__search").addClass('search-active'));
            e.stopPropagation()
        });
        $(document).on('click', function(event) {
            if ($(event.target).is('#search_widget input') == !1) {
                $('.site-header__search').removeClass("search-active");
                $('.search-button').show()
            }
        })
    }

    // Animate load wislist page detail
    $('.group-quantity .btnProductWishlist').click(function () {
        if($(this).hasClass('whislist-added')) {
            $('#popup-Wishlist').removeClass('novload')
        } else {
            $('#popup-Wishlist').addClass('novload')
        }
    })

    //Sticky page cart
    if ($('.template-cart').length > 0 ) {
        novtheme.NovStickIn = function() {
            $(".cart__layout_right").stick_in_parent({
                offset_top: 60
            });
        }
    }
    // Zoom Product Image Page Detail
    if ($(window).width()>=992) {
        var $productImageZoom = $('.image-zoom');
        $productImageZoom.trigger('zoom.destroy');
        $productImageZoom
        .wrap('<span class="w-100" style="display:inline-block"></span>')
        .css('display', 'block')
        .parent()
        .zoom({
        url: $(this).find('img').attr('data-zoom')
        });
    }

    // Product item button sold out
    $('.btnsold_out').click(function () {
        $('.note').addClass("d-none");
        $('.loading').addClass("d-block");
        $('.loading i').addClass("fa-spinner");
        setTimeout(RemoveClass, 500);
    });
    $('.no-view').click(function () {
        if($('.contact-form').hasClass('add')) {
            $('.contact-form').removeClass('add')
        } else {
            $('.contact-form').addClass('add')
        }
    });
    function RemoveClass() {
        $('.note').removeClass("d-none");
        $('.loading').removeClass("d-block");
        $('.loading i').removeClass("zmdi-hc-spin");
    }
    
    // Accordion footer mobile
    $(".f_btn_sl").click(function(e) {
        if ($(this).hasClass("active")) {
            $(this).removeClass('active');
            $(this).parents('.block_footer').find('.block-content.h_t').slideUp(300);
        } else {
            $(".f_btn_sl").removeClass('active');
            $('.block_footer .block-content.h_t').slideUp(300);
            $(this).addClass('active');
            $(this).parents('.block_footer').find('.block-content.h_t').slideDown(300);
        }
    });

    new WOW().init();

    $('.swatch-element[data-toggle="modal"]').click(function () {
        $('.nov-bg').css('opacity', '0');
        $('#content_variants').css('opacity', '0');
    });
    $('#Form_newletter').on('hidden.bs.modal', function () {
      $('.nov-bg').css('opacity', '0.8');
      $('#content_variants').css('opacity', '1');
    });
})
/**
* 2013-2018 Vinovathemes
* @author    Vinovathemes <vinovathemes@gmail.com>
* @copyright 2013-2018 Vinovathemes SA
 */

$.cookie = function(key, value, options) {
    if (arguments.length > 1 && (!/Object/.test(Object.prototype.toString.call(value)) || value === null || value === undefined)) {
        options = $.extend({}, options);
        if (value === null || value === undefined) {
            options.expires = -1
        }
        if (typeof options.expires === 'number') {
            var days = options.expires,
                t = options.expires = new Date();
            t.setDate(t.getDate() + days)
        }
        value = String(value);
        return (document.cookie = [encodeURIComponent(key), '=', options.raw ? value : encodeURIComponent(value), options.expires ? '; expires=' + options.expires.toUTCString() : '', options.path ? '; path=' + options.path : '', options.domain ? '; domain=' + options.domain : '', options.secure ? '; secure' : ''].join(''))
    }
    options = value || {};
    var decode = options.raw ? function(s) {
        return s
    } : decodeURIComponent;
    var pairs = document.cookie.split('; ');
    for (var i = 0, pair; pair = pairs[i] && pairs[i].split('='); i++) {
        if (decode(pair[0]) === key) return decode(pair[1] || '')
    }
    return null
}

/*============================================================================
  Money Format
  - Shopify.format money is defined in option_selection.js.
    If that file is not included, it is redefined here.
==============================================================================*/

if ((typeof Shopify) === 'undefined') { Shopify = {}; }
if (!Shopify.formatMoney) {
  Shopify.formatMoney = function(cents, format) {
    var value = '',
        placeholderRegex = /\{\{\s*(\w+)\s*\}\}/,
        formatString = (format || this.money_format);

    if (typeof cents == 'string') {
      cents = cents.replace('.','');
    }

    function defaultOption(opt, def) {
      return (typeof opt == 'undefined' ? def : opt);
    }

    function formatWithDelimiters(number, precision, thousands, decimal) {
      precision = defaultOption(precision, 2);
      thousands = defaultOption(thousands, ',');
      decimal   = defaultOption(decimal, '.');

      if (isNaN(number) || number == null) {
        return 0;
      }

      number = (number/100.0).toFixed(precision);

      var parts   = number.split('.'),
          dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands),
          cents   = parts[1] ? (decimal + parts[1]) : '';

      return dollars + cents;
    }

    switch(formatString.match(placeholderRegex)[1]) {
      case 'amount':
        value = formatWithDelimiters(cents, 2);
        break;
      case 'amount_no_decimals':
        value = formatWithDelimiters(cents, 0);
        break;
      case 'amount_with_comma_separator':
        value = formatWithDelimiters(cents, 2, '.', ',');
        break;
      case 'amount_no_decimals_with_comma_separator':
        value = formatWithDelimiters(cents, 0, '.', ',');
        break;
    }

    return formatString.replace(placeholderRegex, value);
  };
}

/* ================ Vinovathemes ================ */
window.novtheme = window.novtheme || {};

/*Variable =====================================================*/
var isLoggedIn;
    
     isLoggedIn = false;
    
var current_width = $(window).width(),
    min_width = 768,
    responsive_mobile = current_width < min_width;


/* novtheme Init =====================================================*/
novtheme.init = function () {
    novtheme.cacheSelectors();
    novtheme.hoverBlockCart();
    novtheme.ajaxFilter();
    novtheme.quickview();
    novtheme.popupCart();
    novtheme.ThumbnailProduct();
    novtheme.RelatedProduct();
    novtheme.RelatedBlog();
    novtheme.load_canvas_menu();
    novtheme.click_button_canvas_menu();
    novtheme.productImageSwitch();
    novtheme.Sticky_Menu();
    novtheme.goToTop();
    novtheme.MenuSidebar();
    novtheme.NovToggleAction();
    novtheme.NovToggleSearch();
    novtheme.NovTogglePage();
    novtheme.NovHeightBoxContent();
    novtheme.NovEventClickSearchMobile();
    novtheme.Countdown();
    novtheme.Hienviet();
};

novtheme.swapChildren = function(obj1, obj2) {
    var temp = obj2.children().detach();
    obj2.empty().append(obj1.children().detach());
    obj1.append(temp);
};
novtheme.toggleMobileStyles = function() {
    if (responsive_mobile) {
        $("*[id^='_desktop_']").each(function(idx, el) {
            var target = $('#' + el.id.replace('_desktop_', '_mobile_'));
            if (target) {
                novtheme.swapChildren($(el), target);
            }
        });
    } else {
        $("*[id^='_mobile_']").each(function(idx, el) {
            var target = $('#' + el.id.replace('_mobile_', '_desktop_'));
            if (target) {
                novtheme.swapChildren($(el), target);
            }
        });
    }
};

$(window).on('resize', function() {
    var _cw = current_width;
    var _mw = min_width;
    var _w = $(window).width();
    var _toggle = (_cw >= _mw && _w < _mw) || (_cw < _mw && _w >= _mw);
    responsive_mobile = _cw >= _mw;
    current_width = _w;
    if (_toggle) {
        novtheme.toggleMobileStyles();
        novtheme.load_canvas_menu();
        novtheme.NovTogglePage();
        novtheme.NovHeightBoxContent();
        novtheme.popupCart();
    }
});

//Filter Sidebar
novtheme.ajaxFilter = function(){
    var isAjaxFilterClick =  false;
    if ($(".template-collection")) {
        History.Adapter.bind(window, 'statechange', function() {
            var State = History.getState();
            if (!isAjaxFilterClick) {
                ajaxFilterParams();
                var newurl = ajaxFilterCreateUrl();
                ajaxFilterGetContent(newurl);
            }
        });
    }
    ajaxFilterParams = function () {
        Shopify.queryParams = {};
        if (location.search.length) {
            for (var aKeyValue, i = 0, aCouples = location.search.substr(1).split('&'); i < aCouples.length; i++) {
                aKeyValue = aCouples[i].split('=');
                if (aKeyValue.length > 1) {
                    Shopify.queryParams[decodeURIComponent(aKeyValue[0])] = decodeURIComponent(aKeyValue[1]);
                }
            }
        }
    }
    ajaxFilterCreateUrl = function(baseLink) {
        var newQuery = $.param(Shopify.queryParams).replace(/%2B/g, '+');
        if (baseLink) {
            if (newQuery != "")
                return baseLink + "?" + newQuery;
            else
                return baseLink;
        }
        return location.pathname + "?" + newQuery;
    }
    ajaxFilterClick = function(baseLink) {
        delete Shopify.queryParams.page;
        var newurl = ajaxFilterCreateUrl(baseLink);
        isAjaxFilterClick = true;
        History.pushState({
            param: Shopify.queryParams
        }, newurl, newurl);
        ajaxFilterGetContent(newurl);
    }
    ajaxFilterData = function(data){
        var currentList = $("#shopify-section-collection-template .collection-view-items");
        var dataList = $(data).find("#shopify-section-collection-template .collection-view-items");
        $('.sortPagiBar .showing-total').replaceWith($(data).find(".sortPagiBar .showing-total"));
        currentList.replaceWith(dataList);
        if ($(".nov-pagination", "#shopify-section-collection-template").length > 0) {
            $(".nov-pagination", "#shopify-section-collection-template").replaceWith($(data).find(".nov-pagination"));
        } else {
            $(".collection-view-items").parent().append($(data).find(".nov-pagination"));
        }
        var currentSidebarAjaxFilter = $("#novSidebarAjaxFilter");
        var dataSidebarAjaxFilter = $(data).find("#novSidebarAjaxFilter");
        currentSidebarAjaxFilter.replaceWith(dataSidebarAjaxFilter);
    }

    //Event
    ajaxFilterSortby = function() {
        if (Shopify.queryParams.sort_by) {
            var sortby = Shopify.queryParams.sort_by;
            var text = $('.filters-toolbar__item .dropdown-item.active').html();
            $('.filters-toolbar__item .dropdown-toggle').html(text);
        }
        $('.filters-toolbar__item').on('click','.dropdown-item', function(e){
            e.preventDefault();
            $('.filters-toolbar__item .dropdown-item').removeClass('active');
            $(this).addClass('active');
            $('.filters-toolbar__item .dropdown-toggle').html($(this).html());
            var sortby = $(this).data("value");
            Shopify.queryParams.sort_by = sortby;
            ajaxFilterClick();
        });
    }
    ajaxFilterView = function() {
        $('.gridlist-toggle a').click(function(e) {
            e.preventDefault();
            if (!$(this).hasClass('active')) {
                if ($(this).data('type') == 'list' ) {
                    Shopify.queryParams.view = 'list';
                } else {
                    Shopify.queryParams.view = 'grid';
                }
                $('.gridlist-toggle a').removeClass('active');
                $(this).addClass('active');
                ajaxFilterClick();
            }
        });
    }
    ajaxFilterPaging = function() {
        $('.nov-pagination .pagination a', '#shopify-section-collection-template').click(function(event){
            event.preventDefault();
            var linkPage = $(this).attr("href").match(/page=\d+/g);
            if (linkPage) {
                Shopify.queryParams.page = parseInt(linkPage[0].match(/\d+/g));
                if (Shopify.queryParams.page) {
                    var newurl = ajaxFilterCreateUrl();
                    isAjaxFilterClick = true;
                    History.pushState({
                        param: Shopify.queryParams
                    }, newurl, newurl);
                    ajaxFilterGetContent(newurl);
                    $('body,html').animate({
                        scrollTop: 400
                    }, 600);
                }
            }
        });
    }
    ajaxFilterTags = function() {
        var currentTags = [];
        if (Shopify.queryParams.constraint) {
            currentTags = Shopify.queryParams.constraint.split('+');
            $('.filter-tags .filter-item_content li').each(function(){
                var check = currentTags.indexOf($(this).data('tag'));
                if (check > -1) {
                  $(this).addClass('active');
                }
            })
        }
        $('.filter-tags .filter-item_content li').click(function(event) {
            event.preventDefault();
            var selectedTag = $(this);
            var tagName = selectedTag.data('tag');
            if (tagName) {
                var tagPos = currentTags.indexOf(tagName);
                if (tagPos > -1) {
                    currentTags.splice(tagPos, 1);
                    selectedTag.removeClass('active');
                } else {
                    currentTags.push(tagName);
                    selectedTag.addClass('active');
                }
            }
            if (currentTags.length) {
                Shopify.queryParams.constraint = currentTags.join('+');
            } else {
                delete Shopify.queryParams.constraint;
            }
            ajaxFilterClick();
        });
    }

    ajaxFilterColor = function() {
        var currentTags = [];
        if (Shopify.queryParams.constraint) {
            currentTags = Shopify.queryParams.constraint.split('+');
            $('.filter-color .filter-item_content li').each(function(){
                var check = currentTags.indexOf($(this).data('value'));
                if (check > -1) {
                  $(this).addClass('active');
                }
            })
        }
        $('.filter-color .filter-item_content li').click(function(event) {
            event.preventDefault();
            var selectedTag = $(this);
            var tagName = selectedTag.data('value');
            if (tagName) {
                var tagPos = currentTags.indexOf(tagName);
                if (tagPos > -1) {
                    currentTags.splice(tagPos, 1);
                    selectedTag.removeClass('active');
                } else {
                    currentTags.push(tagName);
                    selectedTag.addClass('active');
                }
            }
            if (currentTags.length) {
                Shopify.queryParams.constraint = currentTags.join('+');
            } else {
                delete Shopify.queryParams.constraint;
            }
            ajaxFilterClick();
        });
    }

    ajaxFilterSize = function() {
        var currentTags = [];
        if (Shopify.queryParams.constraint) {
            currentTags = Shopify.queryParams.constraint.split('+');
            $('.filter-size .filter-item_content li').each(function(){
                var check = currentTags.indexOf($(this).data('value'));
                if (check > -1) {
                  $(this).addClass('active');
                }
            })
        }
        $('.filter-size .filter-item_content li').click(function(event) {
            event.preventDefault();
            var selectedTag = $(this);
            var tagName = selectedTag.data('value');
            if (tagName) {
                var tagPos = currentTags.indexOf(tagName);
                if (tagPos > -1) {
                    currentTags.splice(tagPos, 1);
                    selectedTag.removeClass('active');
                } else {
                    currentTags.push(tagName);
                    selectedTag.addClass('active');
                }
            }
            if (currentTags.length) {
                Shopify.queryParams.constraint = currentTags.join('+');
            } else {
                delete Shopify.queryParams.constraint;
            }
            ajaxFilterClick();
        });
    }
    processFilterPrice = function(minPrice, maxPrice){
        $('#shopify-section-collection-template .collection-view-items .nov-wrapper-product').hide().filter(function() {
            var price = parseInt($(this).data('price'), 10);
            return price >= minPrice && price <= maxPrice;
        }).show();
    };
    ajaxFilterPrice = function() {
        min_price = $('#price-filter-min-text').val();
        max_price =  $('#price-filter-max-text').val();
        $('#nov_slider_price').slider({
            range:true,
            min: $('#nov_slider_price').data('min'),
            max: $('#nov_slider_price').data('max'),
            values: [min_price,max_price],
            slide : function( event, ui ) {
                $('#price-filter-min-text').val(ui.values[0]);
                $('#price-filter-max-text').val(ui.values[1]);
                $('#text-price-filter-min-text').html(ui.values[0]);
                $('#text-price-filter-max-text').html(ui.values[1]);
            },
            change: function( event, ui ) {
                minPrice = $('#nov_slider_price').slider('values', 0);
                maxPrice = $('#nov_slider_price').slider('values', 1);
                $('body,html').animate({
                    scrollTop: 400
                }, 600);
                processFilterPrice(minPrice,maxPrice);
                return false;
            }
        });
    }
    ajaxFilterReview = function() {
        if ($(".shopify-product-reviews-badge").length > 0) {
            return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
        };
    }
    ajaxFilterClear = function() {
        $(".ajaxFilter").each(function() {
            var sidebarTag = $(this);
            if (sidebarTag.find(".listFilter > li.active").length > 0) {
                sidebarTag.find(".novClear").show().click(function(e) {
                    var currentTags = [];
                    if (Shopify.queryParams.constraint) {
                        currentTags = Shopify.queryParams.constraint.split('+');
                    }
                    sidebarTag.find(".listFilter > li.active").each(function() {
                        var selectedTag = $(this);
                        var tagName = selectedTag.data("filter");
                        if (tagName) {
                            var tagPos = currentTags.indexOf(tagName);
                            if (tagPos >= 0) {
                                currentTags.splice(tagPos, 1);
                            }
                        }
                    });
                    if (currentTags.length) {
                        Shopify.queryParams.constraint = currentTags.join('+');
                    } else {
                        delete Shopify.queryParams.constraint;
                    }
                    ajaxFilterClick();
                    e.preventDefault();
                });
            }
        });
    }
    ajaxFilterClearAll = function() {
        $('.list-filter-selected a.novClearAll').click(function(e) {
            delete Shopify.queryParams.constraint;
            delete Shopify.queryParams.q;
            ajaxFilterClick();
            e.preventDefault();
        });
    }
    ajaxFilterAddToCart = function(){
        ajaxCart.init({
            formSelector: '.formAddToCart',
            cartContainer: '#cart-info',
            addToCartSelector: '.btnAddToCart',
            cartCountSelector: '#CartCount, .cart-products-count',
            cartCostSelector: '#CartCost',
            moneyFormat: null
        });
    }

    ajaxFilterGetContent = function(newurl) {
        $.ajax({
            type: 'get',
            url: newurl,
            beforeSend: function() {
                $('.process-loading').show();
            },
            success: function(data) {
                ajaxFilterData(data);
                ajaxFilterSortby();
                ajaxFilterView();
                ajaxFilterTags();
                ajaxFilterSize();
                ajaxFilterColor();
                ajaxFilterPrice();
                ajaxFilterPaging();
                ajaxFilterReview();
                ajaxFilterClearAll();
                $('.process-loading').hide();
                ajaxFilterAddToCart();
                var newTitle = $(data).filter('title').text();
                document.title = newTitle;
                novtheme.wishlistCollectionsLoginCheckHandler();
                if ($('#currencies').length != 0){
                  Currency.convertAll(shopCurrency, $('#currencies span.selected').attr('data-currency'));
                }
            },
            error: function(xhr, text) {
                $('.process-loading').hide();

            }
        });
    }
    ajaxFilterParams();
    ajaxFilterSortby();
    ajaxFilterView();
    ajaxFilterTags();
    ajaxFilterSize();
    ajaxFilterColor();
    ajaxFilterPrice();
    ajaxFilterPaging();
    ajaxFilterClear();
    ajaxFilterClearAll();
}

//Quick View
novtheme.quickview = function(){
    var product = {};
    var option1 = '';
    var option2 = '';
    Shopify.doNotTriggerClickOnThumb = false;
    selectCallbackQuickView = function(variant, selector) {
        var productItem = jQuery('#popup-quickview .proBoxInfo'),
            addToCart = productItem.find('.btnAddToCart'),
            productPrice = productItem.find('.pricePrimary'),
            comparePrice = productItem.find('.priceCompare');
        if (variant) {
            if (variant.available) {
                addToCart.removeClass('disabled').removeAttr('disabled');
                $(addToCart).find("span").text("Add to Cart");
            } else {
                addToCart.addClass('disabled').attr('disabled', 'disabled');
                $(addToCart).find("span").text("Sold Out");
            }
            productPrice.html(Shopify.formatMoney(variant.price, theme.moneyFormat));
            if ( variant.compare_at_price > variant.price ) {
                comparePrice
                    .html(Shopify.formatMoney(variant.compare_at_price, theme.moneyFormat)).show();
            } else {
                comparePrice.hide();
            }
            Currency.convertAll(shopCurrency, $('#currencies span.selected').attr('data-currency'));

                var form = jQuery('#' + selector.domIdPrefix).closest('form');
                for (var i=0,length=variant.options.length; i<length; i++) {
                    var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] +'"]');
                    if (radioButton.size()) {
                        radioButton.get(0).checked = true;
                    }
                }

            if (variant && variant.featured_image) {
                var originalImage = $(".proImageQuickview");
                var newImage = variant.featured_image;
                var element = originalImage[0];
                Shopify.Image.switchImage(newImage, element, function (newImageSizedSrc, newImage, element) {
                    $('.proThumbnails img').each(function() {
                        var parentThumbImg = $(this).parent();
                        var productImage = $(this).parent().data("image");
                        if (newImageSizedSrc.includes(productImage)) {
                            $(this).parent().trigger('click');
                            return false;
                        }
                    });
                });
            }
        } else {
            addToCart.addClass('disabled').attr('disabled', 'disabled');
            $(addToCart).find("span").text("Sold Out");
        }
    }
    changeImageQuickView = function (img, selector) {
        var src = $(img).attr("src");
        src = src.replace("_compact", "");
        $(selector).attr("src", src);
    }
    novUpdateOptionsInSelector = function (t) {
        switch (t) {
        case 0:
            var n = "root";
            var r = $("#popup-quickview .single-option-selector:eq(0)");
            break;
        case 1:
            var n = $("#popup-quickview .single-option-selector:eq(0)").val();
            var r = $("#popup-quickview .single-option-selector:eq(1)");
            break;
        case 2:
            var n = $("#popup-quickview .single-option-selector:eq(0)").val();
            n += " / " + $("#popup-quickview .single-option-selector:eq(1)").val();
            var r = $("#popup-quickview .single-option-selector:eq(2)")
        }
        var i = r.val();
        r.empty();
        var s = Shopify.optionsMapQuickview[n];
        if(typeof s != "undefined"){
            for (var o = 0; o < s.length; o++) {
                var u = s[o];
                var a = $("<option></option>").val(u).html(u);
                r.append(a)
            }
        }
        $('#popup-quickview .swatch[data-option-index="' + t + '"] .swatch-element').each(function() {
            if ($.inArray($(this).attr("data-value"), s) !== -1) {
                $(this).removeClass("soldout").show().find(":radio").removeAttr("disabled", "disabled");
            } else {
                $(this).addClass("soldout").hide().find(":radio").removeAttr("checked").attr("disabled", "disabled")
            }
        });
        if ($.inArray(i, s) !== -1) {
            r.val(i)
        }
        r.trigger("change")
    }
    novLinkOptionSelectors = function (t) {
        for (var n = 0; n < t.variants.length; n++) {
            var r = t.variants[n];
            if (r.available) {
                Shopify.optionsMapQuickview["root"] = Shopify.optionsMapQuickview["root"] || [];
                Shopify.optionsMapQuickview["root"].push(r.option1);
                Shopify.optionsMapQuickview["root"] = Shopify.uniq(Shopify.optionsMapQuickview["root"]);
                if (t.options.length > 1) {
                    var i = r.option1;
                    Shopify.optionsMapQuickview[i] = Shopify.optionsMapQuickview[i] || [];
                    Shopify.optionsMapQuickview[i].push(r.option2);
                    Shopify.optionsMapQuickview[i] = Shopify.uniq(Shopify.optionsMapQuickview[i])
                }
                if (t.options.length === 3) {
                    var i = r.option1 + " / " + r.option2;
                    Shopify.optionsMapQuickview[i] = Shopify.optionsMapQuickview[i] || [];
                    Shopify.optionsMapQuickview[i].push(r.option3);
                    Shopify.optionsMapQuickview[i] = Shopify.uniq(Shopify.optionsMapQuickview[i])
                }
            }
        }
        novUpdateOptionsInSelector(0);
        if (t.options.length > 1)
            novUpdateOptionsInSelector(1);
        if (t.options.length === 3)
            novUpdateOptionsInSelector(2);
        $(".single-option-selector:eq(0)").change(function() {
            novUpdateOptionsInSelector(1);
            if (t.options.length === 3)
                novUpdateOptionsInSelector(2);
            return true
        });
        $(".single-option-selector:eq(1)").change(function() {
            if (t.options.length === 3)
                novUpdateOptionsInSelector(2);
            return true
        });
    }
    loadQuickViewSlider = function (n, r) {
        var loadingImgQuickView = $('.loadingImage');
        var s = Shopify.resizeImage(n.featured_image, "359x");
        loadingImgQuickView.hide();
        if (n.images.length > 0) {
            var o = r.find(".proThumbnailsQuickview .owl-carousel");
            for (i in n.images) {
                var u = Shopify.resizeImage(n.images[i], "359x");
                var a = Shopify.resizeImage(n.images[i], "75x");
                var f = '<div class="thumbItem"><a href="#" data-imageid="' + n.id + '" data-image="' + u + '"><img src="' + a + '" alt="Produc Image" /></a></div>';
                o.append(f)
            }
            o.find("a").click(function(e) {
                e.preventDefault();
                var t = r.find(".proImageQuickview");
                if (t.attr("src") != $(this).attr("data-image")) {
                    t.attr("src", $(this).attr("data-image"));
                    loadingImgQuickView.show();
                    t.load(function(t) {
                        $(this).unbind("load");
                        loadingImgQuickView.hide()
                    })
                }
            });
            o.owlCarousel({
                navText: [ '<i class="fa fa-long-arrow-left"></i>', '<i class="fa fa-long-arrow-right"></i>' ],
                stagePadding: 0,
                items: 5,
                nav: true,
                dots: false,
                margin: 5,
                responsive : {
                    0: {
                        items:4,
                    }
                }
            }).css("visibility", "visible")
        } else {
            r.find("#popup-quickview .proThumbnailsQuickview").remove();
        }
    }
    convertToSlug = function (e) {
        return e.toLowerCase().replace(/[^a-z0-9 -]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-")
    }
    addCheckedSwatch = function (){
        $('.swatch .color label').on('click', function () {
            $('.swatch .color').each(function(){
                $(this).find('label').removeClass('checkedBox');
            });
            $(this).addClass('checkedBox');
        });
    }
    quickViewVariantsSwatch = function (t, quickview) {
        if (t.variants.length > 1) {
            for (var r = 0; r < t.variants.length; r++) {
                var i = t.variants[r];
                var s = '<option value="' + i.id + '">' + i.title + "</option>";
                quickview.find("form.formQuickview .proVariantsQuickview > select").append(s);
            }
            new Shopify.OptionSelectors( 'productSelectQuickview', {
                product: t,
                onVariantSelected: selectCallbackQuickView
            });
            if (t.options.length == 1) {
                $("form.formQuickview .selector-wrapper:eq(0)").prepend("<label>" + t.options[0].name + "</label>")
            }
            quickview.find("form.formQuickview .selector-wrapper label").each(function(n, r) {
                $(this).html(t.options[n].name)
            })

                var o = window.file_url.substring(0, window.file_url.lastIndexOf("?"));
                var u = window.asset_url.substring(0, window.asset_url.lastIndexOf("?"));
                var a = "";
                for (var r = 0; r < t.options.length; r++) {
                    a += '<div class="swatch clearfix" data-option-index="' + r + '">';
                    a += '<div class="header">' + t.options[r].name + "</div>";
                    var f = false;
                    if (/Color|Colour/i.test(t.options[r].name)) { f = true }
                    var l = new Array;
                    for (var c = 0; c < t.variants.length; c++) {
                        var i = t.variants[c]; var h = i.options[r];
                        var p = this.convertToSlug(h);
                        var d = "quickview-swatch-" + r + "-" + p;
                        if (l.indexOf(h) < 0) {
                            a += '<div data-value="' + h + '" class="swatch-element ' + (f ? "color " : "") + p + (i.available ? " available " : " soldout ") + '">';
                            if (f) {
                                a += '<div class="tooltip">' + h + "</div>"
                            }
                            a += '<input id="' + d + '" type="radio" name="option-' + r + '" value="' + h + '" ' + (c == 0 ? " checked " : "") + (i.available ? "" : " disabled") + " />";
                            if (f) {
                                a += '<label class="'+ p +'" for="' + d + '" style="background-color: ' + p + "; background-image: url(" + o + p + '.png)"><img class="crossed-out" src="' + u + 'soldout.png" /><i></i></label>'
                            }
                            else {
                                a += '<label class="'+ p +'" for="' + d + '">' + h + '<img class="crossed-out" src="' + u + 'soldout.png" /></label>'
                            }
                            a += "</div>";
                            if (i.available) {
                                $('#popup-quickview .swatch[data-option-index="' + r + '"] .' + p).removeClass("soldout").addClass("available").find(":radio").removeAttr("disabled")
                            } l.push(h)
                        }
                    } a += "</div>"
                }
                quickview.find("form.formQuickview .proVariantsQuickview > select").after(a);
                quickview.find(".swatch :radio").change(function () {
                    var t = $(this).closest(".swatch").attr("data-option-index");
                    var q = $(this).val();
                    $(this).closest("form").find(".single-option-selector").eq(t).val(q).trigger("change");

                });
                addCheckedSwatch();

            if (t.available) {
                Shopify.optionsMapQuickview = {};
                novLinkOptionSelectors(t);
            }
        }
        else {
            quickview.find("form.formQuickview .proVariantsQuickview > select").remove();
            var v = '<input type="hidden" name="id" value="' + t.variants[0].id + '">';
            quickview.find("form.formQuickview").append(v)
        }
    }
    validateQty = function (qty) {
        if((parseFloat(qty) == parseInt(qty)) && !isNaN(qty)) {

        } else {
            qty = 1;
        }
        return qty;
    };
    $(document).on('click', '.quickviewClose', function(e){
        $("#popup-quickview").html("");
    });
    $(document).on('click', '.btnProductQuickview', function(e){
        var producthandle = $(this).data("handle");
        Shopify.getProduct(producthandle,function(product) {
            var qvhtml = $("#quickviewModal").html();
            $("#popup-quickview").html(qvhtml);
            var quickview= $("#popup-quickview");
            var productdes = product.description.replace(/(<([^>]+)>)/ig,"");
                productdes = productdes.split(" ").splice(0,30).join(" ")+"...";
            var featured_image = Shopify.resizeImage(product.featured_image, "359x");
            quickview.find(".proImageQuickview").attr("src",featured_image);
            quickview.find(".pricePrimary").html(Shopify.formatMoney(product.price, theme.moneyFormat));
            quickview.find(".proBoxInfo").attr("id", "product-" + product.id);
            quickview.find(".formQuickview").attr("id", "product-actions-" + product.id);
            quickview.find(".proBoxInfo .quickviewName").text(product.title);
            quickview.find(".proBoxInfo .quickViewVendor").append("<label>Vendor</label>: " + product.vendor);
            if (product.type) {
                quickview.find(".proBoxInfo .quickViewType").append("<label>Product type</label>: " + product.type);
            } else {
                quickview.find(".proBoxInfo .quickViewType").html("");
            }
            if(product.available){
                quickview.find(".proBoxInfo .quickviewAvailability").append("<label>Availability</label>: In stock");
            }else{
                quickview.find(".proBoxInfo .quickviewAvailability").append("<label>Availability</label>: Unavailable");
            }
            quickview.find(".proShortDescription").text(productdes);
            if (product.compare_at_price > product.price) {
                quickview.find(".priceCompare").html(Shopify.formatMoney(product.compare_at_price_max, theme.moneyFormat)).show();
            }
            else {
                quickview.find(".priceCompare").html("");
            }
            if (!product.available) {
                quickview.find("select, input, .dec, .inc").remove();
                quickview.find(".btnAddToCart").text("Sold Out").addClass("disabled").attr("disabled", "disabled");
                $(".proQuantity").css("display", "none");
            }
            else {
                quickViewVariantsSwatch(product, quickview);
            }
            loadQuickViewSlider(product, quickview);
            $('#popup-quickview').modal();
            $('.js-qty__adjust').on('click', function() {
                var $el = $(this),
                    id = $el.data('id'),
                    $qtySelector = $el.siblings('.js-qty__num'),
                    qty = parseInt($qtySelector.val().replace(/\D/g, ''));
                var qty = validateQty(qty);
                if ($el.hasClass('js-qty__adjust--plus')) {
                    qty += 1;
                } else {
                    qty -= 1;
                    if (qty <= 1) qty = 1;
                }
                $qtySelector.val(qty);
            });
            if ($('#currencies').length != 0){
              Currency.convertAll(shopCurrency, $('#currencies span.selected').attr('data-currency'));
            }
        });
        return false;
    });
};

//Popup Cart
novtheme.popupCart = function(e){
    $(document).on('click', '.popupCartClose, .continue-shopping', function(e){
        e.preventDefault();
        $("#popup-Cart .jsPopupview").html('');
        $('#popup-Cart').modal('toggle');
    });
    $(document).on('click', '.btnAddToCart', function(e){
        var producthandle = $(this).data('handle');
        Shopify.getProduct(producthandle,function(product) {
            var puhtml = $('#PopupCartModal').html();
            $('.jsPopupview').html(puhtml);
            var popupcart = $('.jsPopupview');
            var featured_image = Shopify.resizeImage(product.featured_image, "100x");
            popupcart.find('.proImageProduct').attr('src',featured_image);
            popupcart.find('.proBoxInfo .proName').text(product.title);
            $('#popup-Cart').modal();
        });
    });
};

//Menu CanVas
novtheme.click_button_canvas_menu = function(){
  $('#show-megamenu').on( "click", function() {
    if($('.canvas-menu').hasClass('active')) {
      $('.canvas-menu').removeClass('active');
      $('body').removeClass('canvasmenu-left');
      $(this).removeClass('close');
    }
    else {
      $('.canvas-menu').addClass('active');
      $('body').addClass('canvasmenu-left');
      $(this).addClass('close');
    }
    return false;
  });
}
novtheme.load_canvas_menu = function(){
  var $main_menu = $(".site-nav","#AccessibleNav");
  if(current_width <= 768){
    if($("#canvas-main-menu").length < 1 && $main_menu.length > 0){
      var $menu = $main_menu.parent().clone();
      $menu.attr( "id", "canvas-main-menu");
      $($menu).find(".menu").removeAttr('id');
      $('.canvas-menu').append($menu);
      $menu.mmenu({
        offCanvas: false,
        "navbar": {
          "title": false
        }
      });
      novtheme.remove_canvas_menu();
    }
  }
}
novtheme.remove_canvas_menu = function(){
  $('.canvas-header-box .close-box, .canvas-overlay').on( "click", function() {
    $('.canvas-menu').removeClass('active');
    $('body').removeClass('canvasmenu-left');
    return false;
  });
}

//Thumbnail Image product
novtheme.ThumbnailProduct = function() {
  if($('body').hasClass('lang-rtl'))
      rtl = true;
  else
      rtl = false;
  var autoplay = $("#productThumbs .owl-carousel").data('autoplay');
  var autoplayTimeout = $("#productThumbs .owl-carousel").data('autoplayTimeout');
  var items = $("#productThumbs .owl-carousel").data('items');
  var margin = $("#productThumbs .owl-carousel").data('margin');
  var nav = $("#productThumbs .owl-carousel").data('nav');
  var dots = $("#productThumbs .owl-carousel").data('dots');
  var loop = $("#productThumbs .owl-carousel").data('loop');
  var items_tablet = $("#productThumbs .owl-carousel").data('items_tablet') ? $("#productThumbs .owl-carousel").data('items_tablet') : 3;
  var items_mobile = $("#productThumbs .owl-carousel").data('items_mobile') ? $("#productThumbs .owl-carousel").data('items_mobile') : 1;
  var center = $("#productThumbs .owl-carousel").data('center') ? $("#productThumbs .owl-carousel").data('center') : false;
  var start = $("#productThumbs .owl-carousel").data('start') ? $("#productThumbs .owl-carousel").data('start') : 0;
  $("#productThumbs .owl-carousel").owlCarousel({
    navText: [ '<i class="fa fa-long-arrow-left"></i>', '<i class="fa fa-long-arrow-right"></i>' ],
    lazyLoad         : true,
    lazyContent      : true,
    loop             : loop,
    autoplay         : autoplay,
    autoplayTimeout  : autoplayTimeout,
    items            : items,
    margin           : margin,
    rtl              : rtl,
    dots             : dots,
    nav              : nav,
    responsive       : {
        0 : {
            items: items_mobile,
            center: center,
            margin: 10
        },
        768 : {
            items: items_tablet,
            margin: 10
        },
        992 : {
            items: items,
            margin: margin
        },
        1200 : {
            items: items,
            startPosition: start,
            margin: margin
        },
    }
  });
}

//Related Product
novtheme.RelatedProduct = function() {
  if($('body').hasClass('lang-rtl'))
      rtl = true;
  else
      rtl = false;
  var autoplay = $(".owl-relatedproduct").data('autoplay');
  var autoplayTimeout = $(".owl-relatedproduct").data('autoplayTimeout');
  var items = $(".owl-relatedproduct").data('items');
  var margin = $(".owl-relatedproduct").data('margin');
  var nav = $(".owl-relatedproduct").data('nav');
  var dots = $(".owl-relatedproduct").data('dots');
  var loop = $(".owl-relatedproduct").data('loop');
  var items_tablet = $(".owl-relatedproduct").data('items_tablet') ? $(".owl-relatedproduct").data('items_tablet') : 3;
  var items_mobile = $(".owl-relatedproduct").data('items_mobile') ? $(".owl-relatedproduct").data('items_mobile') : 1;
  var center = $(".owl-relatedproduct").data('center') ? $(".owl-relatedproduct").data('center') : false;
  var start = $(".owl-relatedproduct").data('start') ? $(".owl-relatedproduct").data('start') : 0;
  $(".owl-relatedproduct").owlCarousel({
        navText: [ '<i class="fas fa-long-arrow-alt-left"></i>', '<i class="fas fa-long-arrow-alt-right"></i>' ],
        lazyLoad         : true,
        lazyContent      : true,
        loop             : loop,
        autoplay         : autoplay,
        autoplayTimeout  : autoplayTimeout,
        items            : items,
        margin           : margin,
        rtl              : rtl,
        dots             : dots,
        nav              : nav,
        responsive       : {
            0 : {
                items: items_mobile,
                center: center,
                margin: 10
            },
            768 : {
                items: items_tablet,
                margin: 10
            },
            992 : {
                items: items,
                margin: margin
            },
            1200 : {
                items: items,
                startPosition: start,
                margin: margin
            },
        }
  });
}

//Relate blog blog--list
novtheme.RelatedBlog = function() {
  if($('body').hasClass('lang-rtl'))
      rtl = true;
  else
      rtl = false;
  var $this = $('.BlogRelated .owl-carousel');
  var autoplay = $($this).data('autoplay');
  var autoplayTimeout = $($this).data('autoplayTimeout');
  var items = $($this).data('items');
  var margin = $($this).data('margin');
  var nav = $($this).data('nav');
  var dots = $($this).data('dots');
  var loop = $($this).data('loop');
  var items_tablet = $($this).data('items_tablet') ? $($this).data('items_tablet') : 3;
  var items_mobile = $($this).data('items_mobile') ? $($this).data('items_mobile') : 1;
  var center = $($this).data('center') ? $($this).data('center') : false;
  var start = $($this).data('start') ? $($this).data('start') : 0;
  $($this).owlCarousel({
        navText: [ '<i class="fas fa-long-arrow-alt-left"></i>', '<i class="fas fa-long-arrow-alt-right"></i>' ],
        lazyLoad         : true,
        lazyContent      : true,
        loop             : loop,
        autoplay         : autoplay,
        autoplayTimeout  : autoplayTimeout,
        items            : items,
        margin           : margin,
        rtl              : rtl,
        dots             : dots,
        nav              : nav,
        responsive       : {
            0 : {
                items: items_mobile,
                center: center,
                margin: 10
            },
            768 : {
                items: items_tablet,
                margin: 10
            },
            992 : {
                items: items,
                margin: margin
            },
            1200 : {
                items: items,
                startPosition: start,
                margin: margin
            },
        }
  });
}

novtheme.wishlistCollectionsLoginCheckHandler = function() {
    $(".swym-button").addClass("swym-loaded");
    window._swat.fetch(function(products){
        $(".swym-button").each(function(i){
             var productId = $(this).data("product-id");
             var items = products.filter(function(x){
               return x.et == window._swat.EventTypes.addToWishList && x.empi == productId;
             });
             if(items.length > 0){
               $(this).addClass("swym-added").attr("disabled", true);
             }
             else{
                var me = this;
                $(this).on("click", function(e){
                    e.preventDefault();
                    //if(isLoggedIn) { // code to check for login
                    var productId = $(me).data("product-id");
                    var productData = JSON.parse(JSON.stringify(SwymViewProducts[productId]));
                    productData.et = SwymTracker.EventTypes.addToWishList;
                    _swat.addToWishList(productData, function(){console.log("Added to wishlist");});
                    $(me).addClass("swym-added").attr("disabled", true);
                    //} else {
                        //$('#AlertRequestLogin').modal();
                //}
                });
             }
        });
    });
}

novtheme.novSetAnimate = function(element){
  $_items = $('.item-animate',element);
  $_items.each(function(i){
   $(this).attr("style", "-webkit-animation-delay:" + i * 300 + "ms;"
                 + "-moz-animation-delay:" + i * 300 + "ms;"
                 + "-o-animation-delay:" + i * 300 + "ms;"
                 + "animation-delay:" + i * 300 + "ms;");
  });
}

/*Filter Home Page*/
novtheme.loadmore_product = function(parent) {
    // Locate loadmore button
    var btnloadmore = $('.loadmore', parent);
    var loading_text = $(btnloadmore).data('loading');
    var loadmore_text = $(btnloadmore).data('loadmore');
    var max = $(btnloadmore).data('max');
    var nextpage = $(btnloadmore).data('nextpage');

    // Button position when AJAX call should be made one time
    // Trigger shortcircuit to ensure AJAX only fires once
    triggered = true;

    //remove item class
    $('.item-animate', parent).removeClass('item-animate');
    // Make ajax call to next page for load more data
    $.ajax({
        url: '/?page=' + nextpage,
        type: 'GET',
        beforeSend: function() {
            btnloadmore.html('<span>' + loading_text + '</span>');
            btnloadmore.addClass('loading');
            $('.process-loading').addClass('active');
        }
    })
    .done(function(data) {
        $('.grid--view-items', parent).append($(data).find('.grid--view-items', parent).html());
      	$('.process-loading').removeClass('active');
        novtheme.novSetAnimate();
        btnloadmore.html('<span>' + loadmore_text + '</span>');
        btnloadmore.data('nextpage', nextpage + 1);
        if (nextpage == max) {
            btnloadmore.addClass('hide');
        }
        novtheme.wishlistCollectionsLoginCheckHandler();
        // On success, reset shortcircuit
        triggered = false;
    });
}

novtheme.callbackReview = function() {
    if ($(".shopify-product-reviews-badge").length > 0) {
        return window.SPR.registerCallbacks(), window.SPR.initRatingHandler(), window.SPR.initDomEls(), window.SPR.loadProducts(), window.SPR.loadBadges();
    };
}

novtheme.productPage = function (options) {
  var moneyFormat = options.money_format,
      variant = options.variant,
      selector = options.selector;

  // Selectors
  var $productImage = $('#ProductPhotoImg'),
      $addToCart = $('#AddToCart'),
      $productPrice = $('#ProductPrice-nov-product-template'),
      $comparePrice = $('#ComparePrice-nov-product-template'),
      $quantityElements = $('.quantity-selector, label + .js-qty'),
      $addToCartText = $('#AddToCartText');

  if (variant) {

    if (window.swatch_enable) {
        var form = $('#' + selector.domIdPrefix).closest('form');
        for (var i=0,length=variant.options.length; i<length; i++) {
            var radioButton = form.find('.swatch[data-option-index="' + i + '"] :radio[value="' + variant.options[i] +'"]');
            if (radioButton.size()) {
                radioButton.get(0).checked = true;
            }
        }
    }

    if (variant.featured_image) {
        var newImage = variant.featured_image;
        var element = $productImage[0];
        Shopify.Image.switchImage(newImage, element, function (src, imgObject, el) {
            $('.thumblist img').each(function() {
                var idProductImage = $(this).parent().data('image');
                if (idProductImage == src) {
                    $(this).parent().trigger('click');
                    return false;
                }
            });
        });
    }

    // Select a valid variant if available
    if (variant.available) {
      // Available, enable the submit button, change text, show quantity elements
      $addToCart.removeClass('disabled').prop('disabled', false);
      $addToCartText.html("Add to cart");
      $quantityElements.show();
    } else {
      // Sold out, disable the submit button, change text, hide quantity elements
      $addToCart.addClass('disabled').prop('disabled', true);
      $addToCartText.html("Sold out");
      $quantityElements.hide();
    }

    // Regardless of stock, update the product price
    $productPrice.html( theme.Currency.formatMoney(variant.price, moneyFormat) );

    // Also update and show the product's compare price if necessary
    if (variant.compare_at_price > variant.price) {
      $comparePrice
        .html( theme.Currency.formatMoney(variant.compare_at_price, moneyFormat) )
        .show();
    } else {
      $comparePrice.hide();
    }
    if ($('#currencies').length != 0){
      Currency.convertAll(shopCurrency, $('#currencies span.selected').attr('data-currency'));
    }

  } else {
    // The variant doesn't exist, disable submit button.
    // This may be an error or notice that a specific variant is not available.
    // To only show available variants, implement linked product options:
    //   - http://docs.shopify.com/manual/configuration/store-customization/advanced-navigation/linked-product-options
    $addToCart.addClass('disabled').prop('disabled', true);
    $addToCartText.html("Unavailable");
    $quantityElements.hide();
  }
}

novtheme.productImageSwitch = function () {
    if (novtheme.cache.$thumbImages.length) {
        // Switch the main image with one of the thumbnails
        // Note: this does not change the variant selected, just the image
        $('.thumbItem').each(function(){
            var srcproFeatured = $('#ProductPhotoImg').attr('src');
            var srcthumnail = $('.product-single__thumbnail', this).attr('data-image');
            if (srcproFeatured == srcthumnail) {
                $(this).addClass('active');
            };
        });
        //$('.thumbItem').first().addClass('active');
        novtheme.cache.$thumbImages.on('click', function(evt) {
            evt.preventDefault();
            var newImage = $(this).attr('data-image');
            $('.thumbItem').removeClass('active');
            $(this).parent().addClass('active');
            novtheme.switchImage(newImage, null, novtheme.cache.$productImage);
        });
    }
}

novtheme.switchImage = function (src, imgObject, el) {
  // Make sure element is a jquery object
  var $el = $(el);
  $el.attr('src', src);
}

novtheme.cacheSelectors = function () {
  novtheme.cache = {
    // General
    $html                    : $('html'),
    $body                    : $(document.body),

    // Navigation
    $navigation              : $('#AccessibleNav'),
    $mobileSubNavToggle      : $('.mobile-nav__toggle'),

    // Collection Pages
    $changeView              : $('.change-view'),

    // Product Page
    $productImage            : $('#ProductPhotoImg'),
    $thumbImages             : $('#productThumbs').find('a.product-single__thumbnail'),

    // Customer Pages
    $recoverPasswordLink     : $('#RecoverPassword'),
    $hideRecoverPasswordLink : $('#HideRecoverPasswordLink'),
    $recoverPasswordForm     : $('#RecoverPasswordForm'),
    $customerLoginForm       : $('#CustomerLoginForm'),
    $passwordResetSuccess    : $('#ResetSuccess')
  };
}

//Sticky Menu
novtheme.Sticky_Menu = function () {
    if($('.site-header').hasClass('sticky-menu')) {
        var time;
        $(window).scroll(function(){
            if ( time ) clearTimeout(time);
            time = setTimeout(function(){
                if ($(window).scrollTop() >= 150) {
                    $('.site-header').addClass('sticky-menu-active');
                } else {
                    $('.site-header').removeClass('sticky-menu-active');
                }
            }, 50);
        });
    }
}

//hover block cart
novtheme.hoverBlockCart = function() {
    if (!('ontouchstart' in document)) {
        $('.site-header__cart').hover(function() {
            if (!$('#cart-info').is(':visible')) {
                $("#cart-info").slideDown('fast');
            }
        });
        $('#cart_block').mouseleave(function() {
            $("#cart-info").slideUp('fast');
        });
    } else {
        //mobile
        $('.site-header__cart').click(function() {
            if ($('#cart-info').is(':visible')) {
                $("#cart-info").slideUp('fast');
            } else {
                $("#cart-info").slideDown('fast');
            }
        });
    }
}

novtheme.NovToggleAction = function() {
    $(document).on('click', '.nov-toggle-btn', function(e) {
        var toggle = $(this).data('toggle');
        $(this).toggleClass('act');
        $(this).parent().toggleClass('active');
        $('.canvas-overlay').addClass('act');
        e.stopPropagation();
    });
    $(document).on('click', function(f) {
        if ($(f.target).is('.nov_sideward') == false) {
            $('.nov-toggle').removeClass('active');
            $('.nov-toggle .nov-toggle-btn').removeClass('act');
            $('.canvas-overlay').removeClass('act');
        }
        if ($(f.target).is('.nov-toggle .nov-toggle-btn') == true) {
            $('.nov-toggle').removeClass('active');
            $('.nov-toggle .nov-toggle-btn').removeClass('act');
            $('.canvas-overlay').removeClass('act');
        }
    });
}

// Search toggle.
novtheme.NovToggleSearch = function() {
    $( '.search-toggle' ).on( 'click.break', function( event ) {
        var wrapper = $( '.overlay-search' );
            wrapper.toggleClass( 'open');
            $('.search-bar__form .search-bar__input').focus();
    } );
    $( '.close-search','.overlay-search' ).on( 'click.break', function( event ) {
        var wrapper = $( '.overlay-search' );
            wrapper.toggleClass( 'open');
    } );
}


// Mobile Responsive
novtheme.NovTogglePage = function() {
    $('.nov-toggle-page').on('click', function(e){
        var target = $(this).data('target');
        $('body').hasClass('show-boxpage') ? ( $('body').removeClass('show-boxpage') ) : ( $('body').addClass('show-boxpage') );
        $(target).hasClass('active') ? ( $(target).removeClass('active') ) : ( $(target).addClass('active') );
        e.preventDefault();
    });
    $('.box-header .close-box').on('click', function(e) {
        $('body').removeClass('show-boxpage');
        $(this).parents('.mobile-boxpage').removeClass('active');
        $('.back-box','#mobile-pageaccount').removeClass('active');
        $('#mobile-pageaccount').find('.box-content').removeClass('active');
        e.preventDefault();
    });
    $('.links-currency, .links-language').on('click', function(e) {
        var target_link = $(this).data('target'),
            title_box = $(this).data('titlebox');

        $('#mobile-pageaccount').find('.box-content').removeClass('active');
        $('.title-box','#mobile-pageaccount').html(title_box);
        $('.back-box','#mobile-pageaccount').addClass('active');
        $(target_link).hasClass('active') ? ( $(target_link).removeClass('active') ) : ( $(target_link).addClass('active') );
        e.preventDefault();
    });
    $('.back-box','#mobile-pageaccount').on('click', function(e) {
        var titlebox_parent = $('#mobile-pageaccount').data('titlebox-parent');
        $('#mobile-pageaccount').find('.box-content').removeClass('active');
        $('.title-box','#mobile-pageaccount').html(titlebox_parent);
        $(this).removeClass('active');
        e.preventDefault();
    })
}
novtheme.NovHeightBoxContent = function() {
    var height = $( window ).outerHeight(),
        boxheight = $('.box-header').outerHeight(),
        menubottom = $('#stickymenu_bottom_mobile').outerHeight();
    $('.box-content','.mobile-boxpage').each(function(){
        $(this).outerHeight(height - 45);
    });
}
// Event button search mobile
novtheme.NovEventClickSearchMobile = function() {
    $('#stickymenu_bottom_mobile .js-btn-search').click(function(){
        $('#mobile_search .search-header__input').focus();
        $("body,html").animate({scrollTop:0 },"normal");
    })
}




//Go to top
novtheme.goToTop = function () {
    var timer;
    $(window).scroll(function() {
        if ( timer ) clearTimeout(timer)
        timer = setTimeout(function(){
            if ($(window).scrollTop() >= 100) {
                $('#back-top').fadeIn();
            } else {
                $('#back-top').fadeOut();
            }
        }, 200);

    });
    $("#back-top").click(function(){
        $("body,html").animate({scrollTop:0 },"normal");
        return!1
    });
}

//Popup newsletter
novtheme.PopupNewletter = function () {
    var date = new Date();
    var minutes = 60;
    date.setTime(date.getTime() + (minutes * 60 * 1000));

    if ($.cookie('popupNewLetterStatus') != 'closed' && $('body').outerWidth() > 768) {
        $("#popup-subscribe").modal({
            show: !0
        });
    }
    $.cookie("popupNewLetterStatus", "closed", {
        'expires': date,
        'path': '/'
    })
    $('input.no-view').change(function() {
        if ($('input.no-view').prop("checked") == 1) {
            $.cookie("popupNewLetterStatus", "closed", {
                'expires': date,
                'path': '/'
            })
        } else {
            $.cookie("popupNewLetterStatus", "", {
                'expires': date,
                'path': '/'
            })
        }
    })
}

//Menu sidebar
novtheme.MenuSidebar = function() {
    $('.categories__sidebar .hasSubCategory a').each(function (index) {
        if ($(this).hasClass('active')) {
            $(this).parent().children('.collapse').collapse('show');
        }
    })
}

//Countdown
novtheme.Countdown = function() {
    $('[data-countdown]').each(function() {
        var $this = $(this), finalDate = $(this).data('countdown');
        $this.countdown(finalDate, function(event) {
            var totalHours = event.offset.totalDays * 24 + event.offset.hours;
            var countdown_format = '<div class="item-time"><span class="name-time">Hours</span><span class="data-time"><span>' + totalHours + '</span></span></div>'
                               + '<div class="item-time"><span class="name-time">Mins</span><span class="data-time"><span>%M</span></span></div>'
                               + '<div class="item-time"><span class="name-time">Secs</span><span class="data-time"><span>%S</span></span></div>';
            $this.html(event.strftime(countdown_format));
        });
    });
}

novtheme.Hienviet = function() {
    $(".close-topbar").click(function() {
        $(".topbar").slideUp(500);
        $(".topbar").hide();
        $(".open-topbar").show();
    });
    $(".open-topbar").click(function() {
        $(".topbar").slideDown(100);
        $(".topbar").show();
        $(".open-topbar").hide();
    });

    $(".sidebar-right-title").click(function(){
        $(".sidebar-right-list").addClass('active');
    });
    $(".sidebar-right-list .close-sidebar").click(function(){
        $(".sidebar-right-list").removeClass('active');
    });

    $(".btn-mobile_col-left").click(function(){
        $("#_mobile_colleft").addClass('active');
    });
    $("#_mobile_colleft .close-sidebar").click(function(){
        $("#_mobile_colleft").removeClass('active');
    });
    
    $("#category-home2 .icon_toggle").click(function(e){
        if($(this).parent().hasClass('active')) {
            $(this).parent().removeClass('active');
            $(this).parent().children('.site-nav__dropdown').slideUp(300);
        }
        else {
        $(this).parent().addClass('active').children(".site-nav__dropdown").slideToggle(300);
        }
    });

    $(".menu_toggle").click(function(){
        $("#_desktop_colleft").addClass('active');
    });
    $('.col-right').click(function(){
        $("#_desktop_colleft").removeClass('active');
    });

    /*wpb.productCountdown();
  
    wpb.productCountdown = function() {
       $('[data-countdown]').each(function() {
         var $this = $(this), finalDate = $(this).data('countdown');
         $this.countdown(finalDate, function(event) {
          $this.html(event.strftime(window.countdown_format));
         });
       });
    };*/
}


$(document).ready(function() {
    var d = $(this),
        mobile = false;
    $(novtheme.init);

    //Load cart info
    ajaxCart.load();


    if (responsive_mobile) {
        novtheme.toggleMobileStyles();
    }
    //Popup Newletter
    if ($("#popup-subscribe").length) {
        $(window).on('load', function(){
            var timer = window.setTimeout(novtheme.PopupNewletter(),2000);
        });
    }
    if ($("#popupAlert").length) {
        $(window).on('load', function(){
            $('#popupAlert').modal();
        });
    }
    //
    $(window).on('resize', function() {
        if (d.width() <= 980 && mobile == false) {
            mobile = true;
        } else if (d.width() > 980) {
            mobile = false;
        }
    });
    
    $(".boxInstagram-grid").each(function (i) {
        var Inslimit = $(this).data("limit"),
            InsaccessToken = $(this).data("accesstoken"),
            InsuserId = $(this).data("userid"),
            items = $(this).data("items"),
            value_class = 12/items,
            items_mobile = $(this).data("items_mobile");
        var feed = new Instafeed({
            get: 'user',
            userId: InsuserId,
            accessToken: InsaccessToken,
            limit: 30,
            sortBy: 'least-recent',
            template: '<div class="col-lg-3 col-md-3 col-sm-' + value_class + ' mb-5 col-xs-6"><a href="\{\{link\}\}"><img class="img-fluid" src="\{\{image\}\}" alt="image-instagram"/></a></div>',
            before: function() {},
            after: function() {},
            success: function() {},
            error: function() {}
        });
        feed.run();
    });
});

//_mobile_infos
function NovMobileToggle() {
    if($(document).width() < 1600){
        $('#_mobile_infos .nav-info').on('click', function(e) {
            $('#_mobile_infos').hasClass('active') ? ( $('#_mobile_infos').removeClass('active'), $(this).removeClass('act') ) : ( $('#_mobile_infos').addClass('active'), $(this).addClass('act') );
            e.stopPropagation();
        });
        $(document).on('click', function(vl) {
            if ($(vl.target).is('#_mobile_infos')==false) {
                $('#_mobile_infos').removeClass('active');
            }
        });
    }
}